# ASHWANI — portfolio website

A fast, dark, editorial portfolio site for a freelance graphic designer. It is plain HTML, CSS and JavaScript: no build step, no frameworks, no accounts. Everything you may want to change lives in **one file** (`data/content.js`) and can also be edited with the built-in editor, **Studio**.

---

## 1. What was built

- **Homepage** with the ASHWANI masthead, a headline, a short introduction and two buttons (Explore My Work, Let's Work Together), plus a small preview of your strongest work.
- **Portfolio** with five working filters (YouTube Thumbnails, Logo Design, Posters & Advertising, Social Media Graphics, Other Creative Work). Every design is shown at its real proportions and never cropped. Select one to open a larger view with next and previous buttons. Each project has its own link, so you can share one directly.
- **Services** (six), **About** (with your photo), **How a project runs** (Discuss, Concept, Design, Deliver), **Questions**, and **Contact**.
- **Testimonials** section that stays hidden until you add real ones.
- **Studio**, a private editor for uploading work and changing text without touching code.
- Mobile-first layout, keyboard-friendly, descriptive alt text, share-preview image, page title and description, and no outside services (fonts and everything else are included in the folder).

**What is placeholder right now (all clearly marked on the site):**

- The ten portfolio projects are **samples I designed to show the layout**. Each carries a "Sample" tag. They are not your work and not client work. Replace them with your real projects.
- Email, WhatsApp, Fiverr and Instagram show "Not added yet / Placeholder", and their buttons are switched off until you give real details. Nothing links to a fake address.
- The About text, services text, process and FAQ are written only from the brief. They contain no invented years of experience, clients, prices, delivery times or awards. Read them and make sure every line is true for you.

---

## 2. How to preview or run it

**Quickest:** double-click `index.html`. It opens in your browser and works as it will online.

**Better (optional):** run a tiny local server so it behaves exactly like a live site. In this folder run `python3 -m http.server 8000`, then open `http://localhost:8000`.

**Open Studio:** add `#studio` to the end of the address, for example `index.html#studio` (or `https://yoursite.com/#studio`). After you make your first edit, an "Unpublished edits · Open Studio" button also appears at the bottom-left of the page.

---

## 3. How to add or replace portfolio images

### With Studio (recommended)

1. Open the site with `#studio` at the end of the address.
2. **Work** tab, then **Add project**.
3. Choose your image, or drag it onto the box. Studio resizes and compresses it for the web and keeps its proportions.
4. Type a title, pick a category and add a short description. Fill in the image description (alt text) so people who use screen readers know what the design shows.
5. Optional: add extra images (slides, mockups, colour versions), project details such as Client or Tools, or tick "Show in the preview at the top of the page".
6. **Save project.** It appears on the site straight away, on your device.
7. When your real work is in, press **Remove all samples**.
8. Use the arrows to put your best work first.

### By hand

1. Put your image in `assets/work/` (WebP or JPG, around 2000 px on the long side is plenty). If you also make a smaller copy for the grid (about 1000 px wide), the page loads faster.
2. Open `data/content.js` and copy any block inside `projects: [ ... ]`.
3. Change `id`, `title`, `category`, `description`, `image`, `thumb`, `width`, `height` and `alt`. The width and height must be the real pixel size of the image so the proportions stay correct.
4. Delete `isDemo: true` so the Sample tag disappears.

---

## 4. What I still need from you

| What | Where to add it | Why it matters |
|---|---|---|
| Email address | Studio, Contact tab | Turns on the email link and the "Email this brief" button |
| WhatsApp number, with country code (digits only, e.g. 919876543210) | Studio, Contact tab | Turns on the WhatsApp link and button |
| Fiverr link | Studio, Contact tab | Shows in Contact and the footer |
| Instagram link | Studio, Contact tab | Shows in Contact and the footer |
| Other profiles (Behance, LinkedIn, YouTube…) | Studio, Contact tab, "Other profiles" | Optional extra links |
| Your real projects | Studio, Work tab | The most important part of a portfolio |
| Final website address | Studio, Contact tab, "Website address" | Makes the share-preview image work when someone shares your link |
| Prices (only if you want them shown) | Studio, Text tab, Services | Left empty on purpose. Nothing is invented. |
| Real client feedback (only with permission) | Studio, Text tab, Testimonials | The section stays hidden until you add some |
| Form service address (optional) | Studio, Contact tab | See the note on the contact form below |

**About the contact form.** A website cannot send email by itself. Until you connect a form service (for example Formspree), the form honestly says so and offers three buttons: **Email this brief** and **WhatsApp this brief** (each opens your own app with the message ready; nothing is sent until you press send) and **Copy brief**. If you set up a form service later and paste its address in Studio, the form will send messages itself and show "sent" only when the service confirms it.

---

## 5. What is needed to publish

I have not published the site for you, and no hosting, domain, analytics or form service is set up. To go live you need:

1. **Hosting for a static site.** Any of these can host this folder as it is: Netlify, Cloudflare Pages, GitHub Pages, or any ordinary web hosting. Several have free plans, but check their current terms yourself.
2. **Optional: a domain name** (for example yourname.com) if you want a custom address.
3. **Your real details and work** (section 4), so visitors do not see placeholders.

**Steps**

1. In Studio, open the **Publish** tab and check the list. It tells you what is still missing.
2. Press **Download updated files**. You get a ZIP containing `data/content.js` and all your uploaded images.
3. Unzip it, then copy the `data` and `assets` folders into this website folder, next to `index.html`. Choose Replace or Merge when asked.
4. Upload the whole website folder to your host.
5. When you know your final address, add it in Studio (Contact tab, Website address), download the files again and replace `data/content.js` on the host.

**Good to know**

- Studio saves your edits in **your browser only**. Visitors never see them until you publish the files as above. If you clear your browser data or change device before downloading, the edits are lost, so download regularly.
- Anyone can open `yoursite.com/#studio`, but whatever they change stays in their own browser and cannot touch your live site. If you prefer to hide Studio completely, delete `js/studio.js` and `css/studio.css` before uploading. The rest of the site does not need them.
- The small line under the headline on the homepage is written directly in `index.html` and is not editable in Studio, on purpose.

---

## Folder map

```
index.html          the page
css/styles.css      the design
css/studio.css      Studio design (only loaded when Studio opens)
js/app.js           builds the page from your content, filters, viewer, contact
js/studio.js        the editor (only loaded when Studio opens)
data/content.js     ALL your text, links and projects
assets/work/        portfolio images (+ -sm.webp smaller copies for the grid)
assets/logo/        your photo as the logo, favicons
assets/about/       your portrait for the About section
assets/og/          the share-preview image (1200 × 630)
assets/fonts/       Inter and Lora (open-source, SIL Open Font License), included so nothing loads from outside
```

## What was tested

I tested the site and Studio in Chromium (the engine behind Chrome and Edge) at widths from 320 px to 1920 px: filters, the project viewer, deep links, the Back button, the mobile menu, keyboard use, reduced-motion, uploading, editing, exporting and re-importing content, and that nothing overflows or crops a design. I have **not** tested Safari, Firefox or real phones, so please look at the site on your own phone before sharing it, and tell me if anything looks off.
