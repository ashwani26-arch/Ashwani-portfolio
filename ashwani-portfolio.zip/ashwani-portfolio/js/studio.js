/* =====================================================================
   ASHWANI — Studio
   A private editor that opens on top of the site (add #studio to the
   address, or use the "Open Studio" button that appears after an edit).
   It lets you upload work, change any text and add contact details.

   How it works, in plain words:
   - Your edits are saved in THIS browser only (IndexedDB), so you can
     see the result straight away.
   - Visitors do not see them until you publish. The Publish tab builds
     a ZIP with the updated data/content.js and your new images. Copy
     those into the site folder and upload the folder again.
   - No servers, no accounts, nothing is sent anywhere.
   ===================================================================== */
(function () {
  'use strict';

  var Site = window.Site;
  if (!Site || window.Studio) return;

  /* ---------- helpers ---------- */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var clone = Site.clone;
  var html = document.documentElement;
  var plural = function (n, one, many) { return n + ' ' + (n === 1 ? one : (many || one + 's')); };

  var MAX_EDGE = 2000;          // longest side of the saved main image
  var THUMB_W = 1000;           // width of the grid thumbnail
  var THUMB_H = 1400;
  var DEFAULT_STATUS = 'Edits are saved in this browser only. Use Publish when you are ready to go live.';

  var TABS = [['work', 'Work'], ['text', 'Text'], ['contact', 'Contact'], ['publish', 'Publish']];

  /* ---------- state ---------- */
  var dlg, tabsEl, panel, statusEl;
  var data;                      // working copy of the site content
  var tab = 'work';
  var draft = null;              // project being edited
  var draftIndex = -1;           // -1 means a new project
  var draftNew = false;
  var dirty = false;
  var draftRefs = {};            // images stored while editing, so clean-up never removes them
  var busy = 0;
  var viaHash = false;
  var openGroups = { hero: true };
  var statusTimer;

  /* ---------- small utilities ---------- */
  function getP(obj, path) {
    return path.split('.').reduce(function (o, k) { return o == null ? o : o[k]; }, obj);
  }
  function setP(obj, path, val) {
    var p = path.split('.'), o = obj;
    for (var i = 0; i < p.length - 1; i++) o = o[p[i]];
    o[p[p.length - 1]] = val;
  }

  function say(msg, bad) {
    statusEl.textContent = msg;
    statusEl.className = 'st-status' + (bad ? ' is-bad' : '');
    clearTimeout(statusTimer);
    if (!bad) statusTimer = setTimeout(function () { statusEl.textContent = DEFAULT_STATUS; statusEl.className = 'st-status'; }, 2800);
  }

  function saved(ok, extra) {
    if (ok) say(extra || 'Saved in this browser');
    else say("Couldn't save in this browser (private windows can block this). Download your files from Publish before you leave.", true);
    return ok;
  }

  function commit(keys) {
    var patch = {};
    keys.forEach(function (k) { patch[k] = clone(data[k]); });
    return Site.saveOverrides(patch).then(function (ok) { return saved(ok); });
  }

  // Testimonials only go on the live page once they have both words and a name.
  function saveQuotes() {
    var keep = (data.testimonials || []).filter(function (q) { return q.quote && q.name; });
    var all = (data.testimonials || []).length;
    return Site.saveOverrides({ testimonials: clone(keep) }).then(function (ok) {
      return saved(ok, keep.length === all ? '' : 'Saved. A testimonial shows once it has both words and a name.');
    });
  }

  // Two-step confirmation for destructive buttons: first press arms, second press confirms.
  function arm(btn, msg) {
    if (btn.getAttribute('data-armed')) return true;
    var old = btn.textContent;
    btn.setAttribute('data-armed', '1');
    btn.textContent = msg;
    btn.classList.add('is-armed');
    setTimeout(function () {
      if (btn.isConnected) { btn.removeAttribute('data-armed'); btn.textContent = old; btn.classList.remove('is-armed'); }
    }, 4000);
    return false;
  }

  function slug(s) {
    var t = String(s || '').toLowerCase();
    if (t.normalize) t = t.normalize('NFKD');
    t = t.replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '').slice(0, 40);
    return t || 'project';
  }
  function makeId(title) {
    var id;
    do { id = slug(title) + '-' + Math.random().toString(36).slice(2, 6); }
    while ((data.projects || []).some(function (p) { return p.id === id; }));
    return id;
  }

  function projRefs(p) {
    var r = [p.image, p.thumb];
    (p.gallery || []).forEach(function (g) { r.push(g.image, g.thumb); });
    return r.filter(function (x) { return typeof x === 'string' && x.indexOf('idb:') === 0; });
  }

  // Remove stored images that no project uses any more.
  function cleanup() {
    var keep = {};
    (data.projects || []).forEach(function (p) { projRefs(p).forEach(function (r) { keep[r] = 1; }); });
    Object.keys(draftRefs).forEach(function (r) { keep[r] = 1; });
    return Site.Store.run('img', 'readonly', function (o) { return o.getAllKeys(); }).then(function (keys) {
      (keys || []).forEach(function (k) { if (!keep['idb:' + k]) Site.Store.del('img', k); });
    });
  }

  /* ---------- validation for typed fields ---------- */
  function validate(kind, raw, required) {
    var val = String(raw == null ? '' : raw).trim();
    if (!val) return required ? { ok: false, msg: "This can't be empty." } : { ok: true, value: '' };
    if (kind === 'email') {
      return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(val) ? { ok: true, value: val }
        : { ok: false, msg: "That doesn't look like an email address. Example: name@example.com" };
    }
    if (kind === 'phone') {
      var d = val.replace(/\D/g, '');
      return (d.length >= 8 && d.length <= 15) ? { ok: true, value: d }
        : { ok: false, msg: 'Use the full number with country code, digits only. Example: 919876543210' };
    }
    if (kind === 'url' || kind === 'endpoint') {
      var u = /^https?:\/\//i.test(val) ? val : 'https://' + val;
      try {
        var o = new URL(u);
        if (o.hostname.indexOf('.') < 1) throw new Error('host');
        if (kind === 'endpoint' && o.protocol !== 'https:') throw new Error('https');
        return { ok: true, value: o.href.replace(/\/$/, '') };
      } catch (e) {
        return { ok: false, msg: kind === 'endpoint' ? 'Use the full https:// address your form service gave you.'
          : "That doesn't look like a web address. Example: https://www.instagram.com/yourname" };
      }
    }
    return { ok: true, value: val };
  }

  /* ---------- images: resize, compress, store ---------- */
  function loadImg(file) {
    return new Promise(function (resolve, reject) {
      var url = URL.createObjectURL(file);
      var im = new Image();
      im.onload = function () { resolve({ im: im, url: url }); };
      im.onerror = function () { URL.revokeObjectURL(url); reject(new Error("Your browser can't read " + (file.name || 'that file') + '. Save it as JPG, PNG or WebP and try again.')); };
      im.src = url;
    });
  }
  function drawTo(src, w, h) {
    var c = document.createElement('canvas');
    c.width = w; c.height = h;
    var x = c.getContext('2d');
    x.imageSmoothingEnabled = true; x.imageSmoothingQuality = 'high';
    x.drawImage(src, 0, 0, w, h);
    return c;
  }
  function toBlob(canvas, q, mayHaveAlpha) {
    return new Promise(function (resolve) {
      canvas.toBlob(function (b) {
        if (b && b.type === 'image/webp') { resolve(b); return; }
        canvas.toBlob(function (b2) { resolve(b2); }, mayHaveAlpha ? 'image/png' : 'image/jpeg', q);
      }, 'image/webp', q);
    });
  }

  // Returns { image, thumb, width, height } where image/thumb are "idb:" references.
  function processFile(file) {
    var okType = /^image\//.test(file.type) || /\.(jpe?g|png|webp|gif|avif|svg)$/i.test(file.name || '');
    if (!okType) return Promise.reject(new Error((file.name || 'That file') + ' is not an image.'));
    if (file.size > 40 * 1024 * 1024) return Promise.reject(new Error((file.name || 'That file') + ' is over 40 MB. Please export a smaller copy.'));
    var alpha = /png|svg|gif|webp|avif/i.test(file.type);
    var loaded;
    return loadImg(file).then(function (r) {
      loaded = r;
      var w = r.im.naturalWidth || 1200, h = r.im.naturalHeight || 1200;
      var s = Math.min(1, MAX_EDGE / Math.max(w, h));
      var mw = Math.max(1, Math.round(w * s)), mh = Math.max(1, Math.round(h * s));
      var mainCanvas = drawTo(r.im, mw, mh);
      var ts = Math.min(1, THUMB_W / mw, THUMB_H / mh);
      var thumbCanvas = ts < 0.85 ? drawTo(mainCanvas, Math.max(1, Math.round(mw * ts)), Math.max(1, Math.round(mh * ts))) : null;
      return Promise.all([
        toBlob(mainCanvas, 0.88, alpha),
        thumbCanvas ? toBlob(thumbCanvas, 0.82, alpha) : Promise.resolve(null)
      ]).then(function (blobs) {
        URL.revokeObjectURL(r.url);
        if (!blobs[0]) throw new Error("Couldn't prepare " + (file.name || 'that image') + '.');
        return Site.addImage(blobs[0]).then(function (a) {
          draftRefs[a.ref] = 1;
          if (!a.stored) throw new Error("Couldn't store the image in this browser (private windows can block this).");
          if (!blobs[1]) return { image: a.ref, thumb: '', width: mw, height: mh };
          return Site.addImage(blobs[1]).then(function (b) {
            draftRefs[b.ref] = 1;
            return { image: a.ref, thumb: b.ref, width: mw, height: mh };
          });
        });
      });
    }).catch(function (err) {
      if (loaded) URL.revokeObjectURL(loaded.url);
      throw err;
    });
  }

  /* ---------- ZIP writer (store only, no compression, no libraries) ---------- */
  var crcTable = (function () {
    var t = new Uint32Array(256);
    for (var n = 0; n < 256; n++) {
      var c = n;
      for (var k = 0; k < 8; k++) c = (c & 1) ? (0xEDB88320 ^ (c >>> 1)) : (c >>> 1);
      t[n] = c >>> 0;
    }
    return t;
  })();
  function crc32(u8) {
    var c = 0xFFFFFFFF;
    for (var i = 0; i < u8.length; i++) c = crcTable[(c ^ u8[i]) & 255] ^ (c >>> 8);
    return (c ^ 0xFFFFFFFF) >>> 0;
  }
  function makeZip(files) {
    var enc = new TextEncoder();
    var d = new Date();
    var time = (d.getHours() << 11) | (d.getMinutes() << 5) | (d.getSeconds() >> 1);
    var date = ((d.getFullYear() - 1980) << 9) | ((d.getMonth() + 1) << 5) | d.getDate();
    var parts = [], central = [], offset = 0;
    files.forEach(function (f) {
      var name = enc.encode(f.name), crc = crc32(f.data), size = f.data.length;
      var lh = new DataView(new ArrayBuffer(30));
      lh.setUint32(0, 0x04034b50, true); lh.setUint16(4, 20, true); lh.setUint16(6, 0x0800, true); lh.setUint16(8, 0, true);
      lh.setUint16(10, time, true); lh.setUint16(12, date, true); lh.setUint32(14, crc, true);
      lh.setUint32(18, size, true); lh.setUint32(22, size, true); lh.setUint16(26, name.length, true); lh.setUint16(28, 0, true);
      parts.push(lh.buffer, name, f.data);
      var ch = new DataView(new ArrayBuffer(46));
      ch.setUint32(0, 0x02014b50, true); ch.setUint16(4, 20, true); ch.setUint16(6, 20, true); ch.setUint16(8, 0x0800, true); ch.setUint16(10, 0, true);
      ch.setUint16(12, time, true); ch.setUint16(14, date, true); ch.setUint32(16, crc, true);
      ch.setUint32(20, size, true); ch.setUint32(24, size, true); ch.setUint16(28, name.length, true);
      ch.setUint16(30, 0, true); ch.setUint16(32, 0, true); ch.setUint16(34, 0, true); ch.setUint16(36, 0, true);
      ch.setUint32(38, 0, true); ch.setUint32(42, offset, true);
      central.push(ch.buffer, name);
      offset += 30 + name.length + size;
    });
    var cdSize = central.reduce(function (a, p) { return a + p.byteLength; }, 0);
    var end = new DataView(new ArrayBuffer(22));
    end.setUint32(0, 0x06054b50, true); end.setUint16(8, files.length, true); end.setUint16(10, files.length, true);
    end.setUint32(12, cdSize, true); end.setUint32(16, offset, true);
    return new Blob(parts.concat(central, [end.buffer]), { type: 'application/zip' });
  }

  function extFor(blob) {
    return { 'image/webp': '.webp', 'image/jpeg': '.jpg', 'image/png': '.png' }[blob.type] || '.webp';
  }

  /* Build data/content.js and gather every image the content points to. */
  function buildExport() {
    var content = clone(data);
    var files = [], map = {}, taken = {};
    function unique(name) {
      var n = name, i = 2, dot = name.lastIndexOf('.');
      while (taken[n]) { n = name.slice(0, dot) + '-' + i + name.slice(dot); i++; }
      taken[n] = 1;
      return n;
    }
    function resolve(ref, stem) {
      if (!ref || ref.indexOf('idb:') !== 0) return Promise.resolve(ref);
      if (map[ref]) return Promise.resolve(map[ref]);
      return Site.getBlob(ref).then(function (blob) {
        if (!blob) throw new Error('One of your images is missing from this browser. Re-upload it in the Work tab.');
        var name = unique('assets/work/' + stem + extFor(blob));
        map[ref] = name;
        return blob.arrayBuffer().then(function (buf) {
          files.push({ name: name, data: new Uint8Array(buf) });
          return name;
        });
      });
    }
    var chain = Promise.resolve();
    (content.projects || []).forEach(function (p) {
      var stem = slug(p.id);
      chain = chain.then(function () { return resolve(p.image, stem); }).then(function (v) { p.image = v; })
        .then(function () { return resolve(p.thumb, stem + '-sm'); }).then(function (v) { if (v) p.thumb = v; else delete p.thumb; });
      (p.gallery || []).forEach(function (g, i) {
        chain = chain.then(function () { return resolve(g.image, stem + '-' + (i + 2)); }).then(function (v) { g.image = v; })
          .then(function () { return resolve(g.thumb, stem + '-' + (i + 2) + '-sm'); }).then(function (v) { if (v) g.thumb = v; else delete g.thumb; });
      });
    });
    return chain.then(function () {
      var stamp = new Date().toISOString().slice(0, 10);
      var js = '/* =====================================================================\n' +
        '   ASHWANI — SITE CONTENT\n' +
        '   Written by Studio on ' + stamp + '.\n' +
        '   You can keep editing this file by hand, or open the site with #studio\n' +
        '   at the end of the address to use the editor again.\n' +
        '   Anything left as "" (empty) shows as a clearly marked placeholder.\n' +
        '   ===================================================================== */\n' +
        'window.SITE_CONTENT = ' + JSON.stringify(content, null, 2) + ';\n';
      var readme = 'ASHWANI site update (' + stamp + ')\r\n\r\n' +
        '1. Unzip this file. You will see a "data" folder and an "assets" folder.\r\n' +
        '2. Copy both folders into your website folder, next to index.html.\r\n' +
        '   Choose "Replace" or "Merge" when your computer asks.\r\n' +
        '3. Upload the website folder to your hosting again.\r\n';
      var enc = new TextEncoder();
      var all = [{ name: 'data/content.js', data: enc.encode(js) }].concat(files, [{ name: 'README.txt', data: enc.encode(readme) }]);
      return { blob: makeZip(all), images: files.length, bytes: files.reduce(function (a, f) { return a + f.data.length; }, 0), stamp: stamp };
    });
  }

  /* ---------- building blocks for forms ---------- */
  function fieldHTML(label, path, o) {
    o = o || {};
    var v = getP(data, path);
    if (o.lines) v = (v || []).join('\n');
    if (o.paras) v = (v || []).join('\n\n');
    var id = 'f-' + path.replace(/\./g, '-');
    var attrs = ' id="' + id + '" data-p="' + esc(path) + '"' +
      (o.as ? ' data-as="' + o.as + '"' : '') + (o.v ? ' data-v="' + o.v + '"' : '') + (o.req ? ' data-req="1"' : '') +
      (o.ph ? ' placeholder="' + esc(o.ph) + '"' : '') + (o.hint ? ' aria-describedby="' + id + '-h"' : '');
    var control = o.rows
      ? '<textarea rows="' + o.rows + '"' + attrs + '>' + esc(v) + '</textarea>'
      : '<input type="text"' + attrs + ' value="' + esc(v) + '" autocomplete="off"' + (o.mode ? ' inputmode="' + o.mode + '"' : '') + ' spellcheck="' + (o.v ? 'false' : 'true') + '">';
    return '<div class="st-field"><label for="' + id + '">' + esc(label) + '</label>' +
      (o.hint ? '<p class="st-hint" id="' + id + '-h">' + esc(o.hint) + '</p>' : '') + control + '<p class="st-msg" role="alert"></p></div>';
  }

  function group(id, title, body, note) {
    return '<details class="st-group" data-g="' + id + '"' + (openGroups[id] ? ' open' : '') + '><summary>' + esc(title) + '</summary>' +
      '<div class="st-group__body">' + (note ? '<p class="st-note">' + esc(note) + '</p>' : '') + body + '</div></details>';
  }

  function checkHTML(key, label, hint, checked, disabled) {
    var id = 'st-d-' + key;
    return '<div class="st-check"><input type="checkbox" id="' + id + '" data-d="' + key + '"' + (checked ? ' checked' : '') + (disabled ? ' disabled' : '') + '>' +
      '<label for="' + id + '"><span>' + esc(label) + '</span>' + (hint ? '<small>' + esc(hint) + '</small>' : '') + '</label></div>';
  }

  /* ---------- tabs ---------- */
  function renderTabs() {
    tabsEl.innerHTML = TABS.map(function (t) {
      var on = t[0] === tab;
      return '<button type="button" role="tab" id="st-tab-' + t[0] + '" aria-selected="' + on + '" aria-controls="st-panel" tabindex="' + (on ? 0 : -1) + '" data-tab="' + t[0] + '">' + t[1] + '</button>';
    }).join('');
    panel.setAttribute('aria-labelledby', 'st-tab-' + tab);
  }

  function blockedByDraft() {
    if (busy) {
      say('Please wait while your image is prepared.', true);
      return true;
    }
    if (draft && dirty) {
      say('You have an unsaved project. Save it, or choose "Back to list" to discard it.', true);
      return true;
    }
    return false;
  }

  function switchTab(t, focusTab) {
    if (t === tab) return;
    if (blockedByDraft()) return;
    if (draft) { draft = null; draftRefs = {}; cleanup(); }
    tab = t;
    renderTabs(); renderTab();
    if (focusTab) $('#st-tab-' + t).focus();
    panel.scrollTop = 0;
  }

  function renderTab() {
    var top = panel.scrollTop;
    if (tab === 'work') (draft ? renderForm : renderWork)();
    else if (tab === 'text') renderText();
    else if (tab === 'contact') renderContact();
    else renderPublish();
    panel.scrollTop = top;
  }

  /* ---------- WORK: list ---------- */
  function renderWork() {
    var ps = data.projects || [];
    var samples = ps.filter(function (p) { return p.isDemo; }).length;
    var out = '<div class="st-head"><div><h3 class="st-h" id="st-h" tabindex="-1">Your work</h3>' +
      '<p class="st-lead">' + plural(ps.length, 'project') + (samples ? ', ' + samples + ' of them ' + (samples === 1 ? 'a sample' : 'samples') : '') + '. Visitors see them in this order.</p></div>' +
      '<div class="st-actions"><button type="button" class="st-btn st-btn--primary" data-act="add">Add project</button>' +
      (samples ? '<button type="button" class="st-btn" data-act="rm-samples">Remove all samples</button>' : '') + '</div></div>';
    if (samples) out += '<p class="st-note">Projects tagged <b>Sample</b> are placeholders that show how the portfolio will look. They are not client work. Remove them before you publish.</p>';
    if (!ps.length) {
      out += '<p class="st-empty">No projects yet. Press <b>Add project</b> to upload your first piece of work.</p>';
    } else {
      out += '<ol class="st-list">' + ps.map(function (p, i) {
        var meta = Site.catLabel(p.category) + (p.width ? ' · ' + p.width + ' × ' + p.height : '') +
          (p.gallery && p.gallery.length ? ' · +' + plural(p.gallery.length, 'image') : '');
        return '<li class="st-item"><div class="st-thumb"><img src="' + esc(Site.src(p.thumb || p.image)) + '" alt="" loading="lazy"></div>' +
          '<div class="st-item__main"><p class="st-item__title">' + esc(p.title) + (p.isDemo ? ' <span class="st-tag">Sample</span>' : '') + '</p>' +
          '<p class="st-item__meta">' + esc(meta) + '</p></div>' +
          '<div class="st-item__act">' +
          '<button type="button" class="st-icon" data-act="up" data-i="' + i + '" aria-label="Move ' + esc(p.title) + ' up"' + (i === 0 ? ' disabled' : '') + '>' + chev('up') + '</button>' +
          '<button type="button" class="st-icon" data-act="down" data-i="' + i + '" aria-label="Move ' + esc(p.title) + ' down"' + (i === ps.length - 1 ? ' disabled' : '') + '>' + chev('down') + '</button>' +
          '<button type="button" class="st-btn st-btn--sm" data-act="edit" data-i="' + i + '" aria-label="Edit ' + esc(p.title) + '">Edit</button>' +
          '<button type="button" class="st-btn st-btn--sm st-btn--danger" data-act="del" data-i="' + i + '" aria-label="Delete ' + esc(p.title) + '">Delete</button>' +
          '</div></li>';
      }).join('') + '</ol>';
    }
    panel.innerHTML = out;
  }

  function chev(dir) {
    return '<svg width="16" height="16" viewBox="0 0 16 16" aria-hidden="true"><path d="' + (dir === 'up' ? 'M3 10l5-5 5 5' : 'M3 6l5 5 5-5') + '" fill="none" stroke="currentColor" stroke-width="1.8" stroke-linecap="square"/></svg>';
  }

  /* ---------- WORK: project form ---------- */
  function startDraft(i) {
    draftIndex = i;
    draftNew = i < 0;
    var base = {
      id: '', title: '', category: (data.categories[0] || {}).id || 'other', description: '',
      image: '', thumb: '', width: 0, height: 0, alt: '', format: '',
      isDemo: false, featured: false, size: '', pad: false, gallery: [], details: []
    };
    draft = i < 0 ? base : Object.assign(base, clone(data.projects[i]));
    draft.gallery = draft.gallery || [];
    draft.details = draft.details || [];
    draftRefs = {};
    dirty = false;
    renderForm();
    panel.scrollTop = 0;
    var h = $('#st-h'); if (h) h.focus();
  }

  function renderForm() {
    var d = draft;
    var ratio = d.width && d.height ? d.width / d.height : 0;
    var catOpts = data.categories.map(function (c) {
      return '<option value="' + esc(c.id) + '"' + (c.id === d.category ? ' selected' : '') + '>' + esc(c.label) + '</option>';
    }).join('');

    var drop = '<div class="st-drop" data-drop>' +
      (d.image
        ? '<img class="st-drop__img" src="' + esc(Site.src(d.image)) + '" alt="Preview of the main image">' +
          '<p class="st-drop__dims">' + d.width + ' × ' + d.height + ' px, saved at full proportions</p>'
        : '<p class="st-drop__hint"><b>Drop an image here</b>, or choose one. JPG, PNG or WebP. It is resized and compressed for the web, and never cropped.</p>') +
      '<label class="st-btn st-filebtn"><span>' + (d.image ? 'Replace image' : 'Choose image') + '</span><input type="file" id="st-pick" accept="image/*" data-file="main" class="sr-only"></label></div>';

    var extra = '<div class="st-sec"><h4>More images <span>optional</span></h4>' +
      '<p class="st-hint">Extra slides, mockups or colour versions. They appear inside the project view.</p>' +
      (d.gallery.length ? '<ul class="st-gal">' + d.gallery.map(function (g, i) {
        return '<li><img src="' + esc(Site.src(g.thumb || g.image)) + '" alt=""><div class="st-field"><label for="st-g-' + i + '">Description of image ' + (i + 2) + '</label>' +
          '<input type="text" id="st-g-' + i + '" data-gi="' + i + '" value="' + esc(g.alt) + '" placeholder="What does this image show?" autocomplete="off"></div>' +
          '<button type="button" class="st-btn st-btn--sm st-btn--danger" data-act="g-del" data-i="' + i + '" aria-label="Remove image ' + (i + 2) + '">Remove</button></li>';
      }).join('') + '</ul>' : '') +
      '<label class="st-btn st-filebtn"><span>Add images</span><input type="file" accept="image/*" multiple data-file="extra" class="sr-only"></label></div>';

    var details = '<div class="st-sec"><h4>Project details <span>optional</span></h4>' +
      '<p class="st-hint">Only facts that are true, such as Client, Tools or Year. Leave this empty if you are unsure.</p>' +
      d.details.map(function (x, i) {
        return '<div class="st-pair"><input type="text" data-di="' + i + '" data-dk="label" value="' + esc(x.label) + '" placeholder="Label" aria-label="Detail ' + (i + 1) + ' label" autocomplete="off">' +
          '<input type="text" data-di="' + i + '" data-dk="value" value="' + esc(x.value) + '" placeholder="Value" aria-label="Detail ' + (i + 1) + ' value" autocomplete="off">' +
          '<button type="button" class="st-icon" data-act="d-del" data-i="' + i + '" aria-label="Remove detail ' + (i + 1) + '">' + cross() + '</button></div>';
      }).join('') +
      '<button type="button" class="st-btn st-btn--sm" data-act="d-add">Add detail</button></div>';

    panel.innerHTML = '<form id="st-form" novalidate>' +
      '<div class="st-head"><div><h3 class="st-h" id="st-h" tabindex="-1">' + (draftNew ? 'Add project' : 'Edit project') + '</h3>' +
      '<p class="st-lead">Fill in what you know. Only the title, category and main image are needed.</p></div>' +
      '<div class="st-actions"><button type="button" class="st-btn" data-act="cancel">Back to list</button>' +
      '<button type="submit" class="st-btn st-btn--primary" data-act="save">Save project</button></div></div>' +
      '<div class="st-err" id="st-ferr" role="alert" tabindex="-1" hidden></div>' +
      '<div class="st-cols"><div class="st-col">' + drop + extra + '</div><div class="st-col">' +
      '<div class="st-field"><label for="st-d-title">Title</label><input type="text" id="st-d-title" data-d="title" value="' + esc(d.title) + '" autocomplete="off"></div>' +
      '<div class="st-field"><label for="st-d-category">Category</label><select id="st-d-category" data-d="category">' + catOpts + '</select></div>' +
      '<div class="st-field"><label for="st-d-description">Short description</label><p class="st-hint" id="st-d-description-h">One or two sentences: the goal, the audience or what you made.</p>' +
      '<textarea id="st-d-description" data-d="description" rows="4" aria-describedby="st-d-description-h">' + esc(d.description) + '</textarea></div>' +
      '<div class="st-field"><label for="st-d-alt">Image description (alt text)</label><p class="st-hint" id="st-d-alt-h">Describe what the image shows, for people who use screen readers. If you leave it empty the title is used.</p>' +
      '<input type="text" id="st-d-alt" data-d="alt" value="' + esc(d.alt) + '" aria-describedby="st-d-alt-h" autocomplete="off"></div>' +
      '<div class="st-field"><label for="st-d-format">Format label</label><p class="st-hint" id="st-d-format-h">Shown under the title. For example 1280 × 720 px, or Logo and colour versions.</p>' +
      '<input type="text" id="st-d-format" data-d="format" value="' + esc(d.format) + '" aria-describedby="st-d-format-h" autocomplete="off"></div>' +
      '<fieldset class="st-checks"><legend>Options</legend>' +
      checkHTML('featured', 'Show in the preview at the top of the page', 'Pick your strongest two or three.', d.featured) +
      checkHTML('size', 'Make it wide on big screens', ratio && ratio < 1.2 ? 'Works best with wide images, so it is off for this one.' : 'Good for thumbnails and other wide designs.', d.size === 'large', ratio && ratio < 1.2) +
      checkHTML('pad', 'This is a logo on a transparent background', 'Adds space around it so it is not pushed against the edge.', d.pad) +
      checkHTML('isDemo', 'This is a sample, not my real work', 'Adds a Sample tag. Leave it off for real projects.', d.isDemo) +
      '</fieldset>' + details + '</div></div></form>';
  }

  function cross() {
    return '<svg width="14" height="14" viewBox="0 0 14 14" aria-hidden="true"><path d="M2 2l10 10M12 2L2 12" stroke="currentColor" stroke-width="1.8" fill="none" stroke-linecap="square"/></svg>';
  }

  function formError(list) {
    var box = $('#st-ferr');
    if (!box) return;
    if (!list || !list.length) { box.hidden = true; box.innerHTML = ''; return; }
    box.innerHTML = '<p><b>Almost there.</b></p><ul>' + list.map(function (m) { return '<li>' + esc(m) + '</li>'; }).join('') + '</ul>';
    box.hidden = false;
    box.focus();
  }

  function setBusy(on, msg) {
    busy += on ? 1 : -1;
    if (busy < 0) busy = 0;
    var save = $('[data-act="save"]');
    if (save) save.disabled = busy > 0;
    if (on) say(msg || 'Working…');
  }

  function addFiles(kind, fileList) {
    var files = Array.prototype.slice.call(fileList || []);
    if (!files.length || !draft) return;
    if (kind === 'main') files = files.slice(0, 1);
    setBusy(true, files.length > 1 ? 'Preparing ' + files.length + ' images…' : 'Preparing image…');
    var errors = [];
    var chain = Promise.resolve();
    files.forEach(function (f) {
      chain = chain.then(function () {
        return processFile(f).then(function (r) {
          dirty = true;
          if (kind === 'main') {
            draft.image = r.image; draft.thumb = r.thumb; draft.width = r.width; draft.height = r.height;
            if (draftNew && !draft.size && r.width / r.height >= 1.5) draft.size = 'large';
            if (r.width / r.height < 1.2 && draft.size) draft.size = '';
          } else {
            draft.gallery.push({ image: r.image, thumb: r.thumb, width: r.width, height: r.height, alt: '' });
          }
        }).catch(function (err) { errors.push(err.message || String(err)); });
      });
    });
    return chain.then(function () {
      setBusy(false);
      renderTab();
      formError(errors);
      if (!errors.length) say(kind === 'main' ? 'Image added' : 'Images added');
    });
  }

  function saveDraft() {
    var d = draft, errs = [];
    d.title = (d.title || '').trim();
    if (!d.title) errs.push('Give the project a title.');
    if (!d.image) errs.push('Add the main image.');
    if (!d.category) errs.push('Choose a category.');
    if (busy) errs.push('An image is still being prepared. Try again in a moment.');
    if (errs.length) { formError(errs); return; }
    formError([]);

    var p = { id: d.id || makeId(d.title), title: d.title, category: d.category, description: (d.description || '').trim(), image: d.image };
    if (d.thumb) p.thumb = d.thumb;
    p.width = d.width; p.height = d.height;
    p.alt = (d.alt || '').trim() || d.title;
    if ((d.format || '').trim()) p.format = d.format.trim();
    if (d.isDemo) p.isDemo = true;
    if (d.featured) p.featured = true;
    if (d.size) p.size = 'large';
    if (d.pad) p.pad = true;
    var gal = d.gallery.filter(function (g) { return g.image; }).map(function (g, i) {
      var o = { image: g.image };
      if (g.thumb) o.thumb = g.thumb;
      o.width = g.width; o.height = g.height;
      o.alt = (g.alt || '').trim() || d.title + ' (image ' + (i + 2) + ')';
      return o;
    });
    if (gal.length) p.gallery = gal;
    var det = d.details.map(function (x) { return { label: (x.label || '').trim(), value: (x.value || '').trim() }; })
      .filter(function (x) { return x.label && x.value; });
    if (det.length) p.details = det;

    if (draftIndex >= 0) data.projects[draftIndex] = p; else data.projects.unshift(p);
    commit(['projects']).then(function () {
      draft = null; dirty = false; draftRefs = {};
      cleanup();
      renderTab();
      var h = $('#st-h'); if (h) h.focus();
      say('Project saved');
    });
  }

  /* ---------- TEXT ---------- */
  function renderText() {
    var hero = fieldHTML('Role line under ASHWANI', 'site.role', { req: 1 }) +
      fieldHTML('Main headline', 'hero.headline', { req: 1 }) +
      fieldHTML('Introduction', 'hero.intro', { req: 1, rows: 3 }) +
      fieldHTML('Main button text', 'hero.primaryCta', { req: 1 }) +
      fieldHTML('Second button text', 'hero.secondaryCta', { req: 1 });

    var about = fieldHTML('Heading', 'about.heading', { req: 1 }) +
      fieldHTML('About text', 'about.paragraphs', { rows: 8, paras: 1, as: 'paras', hint: 'Leave a blank line between paragraphs.' }) +
      fieldHTML('What I create', 'about.makes', { rows: 6, lines: 1, as: 'lines', hint: 'One item per line.' }) +
      fieldHTML('Who I work with', 'about.for', { rows: 5, lines: 1, as: 'lines', hint: 'One item per line.' });

    var services = (data.services || []).map(function (s, i) {
      return '<fieldset class="st-set"><legend>' + esc(s.title) + '</legend>' +
        fieldHTML('Title', 'services.' + i + '.title', { req: 1 }) +
        fieldHTML('Description', 'services.' + i + '.text', { req: 1, rows: 3 }) +
        fieldHTML('Price (optional)', 'services.' + i + '.price', { hint: 'Leave empty to show no price. Only add a price you have confirmed, for example "From 20 USD".' }) +
        '</fieldset>';
    }).join('');

    var process = (data.process || []).map(function (s, i) {
      return '<fieldset class="st-set"><legend>Step ' + (i + 1) + '</legend>' +
        fieldHTML('Title', 'process.' + i + '.title', { req: 1 }) +
        fieldHTML('Description', 'process.' + i + '.text', { req: 1, rows: 2 }) + '</fieldset>';
    }).join('');

    var faq = (data.faq || []).map(function (f, i) {
      return '<fieldset class="st-set"><legend>Question ' + (i + 1) + '</legend>' +
        fieldHTML('Question', 'faq.' + i + '.q', { req: 1 }) +
        fieldHTML('Answer', 'faq.' + i + '.a', { req: 1, rows: 3 }) +
        '<button type="button" class="st-btn st-btn--sm st-btn--danger" data-act="faq-del" data-i="' + i + '">Delete question</button></fieldset>';
    }).join('') + '<button type="button" class="st-btn" data-act="faq-add">Add a question</button>';

    var quotes = (data.testimonials || []).map(function (t, i) {
      return '<fieldset class="st-set"><legend>Testimonial ' + (i + 1) + '</legend>' +
        fieldHTML('What they said', 'testimonials.' + i + '.quote', { rows: 3 }) +
        fieldHTML('Their name', 'testimonials.' + i + '.name') +
        fieldHTML('Their role or channel (optional)', 'testimonials.' + i + '.role') +
        '<button type="button" class="st-btn st-btn--sm st-btn--danger" data-act="q-del" data-i="' + i + '">Delete testimonial</button></fieldset>';
    }).join('') + '<button type="button" class="st-btn" data-act="q-add">Add a testimonial</button>';

    panel.innerHTML = '<div class="st-head"><div><h3 class="st-h" id="st-h" tabindex="-1">Text</h3>' +
      '<p class="st-lead">Change any wording on the site. Each edit saves when you leave the field.</p></div></div>' +
      group('hero', 'Top of the page', hero) +
      group('about', 'About', about, 'Write only what is true. Do not add years of experience, awards or client names you cannot back up.') +
      group('services', 'Services', services) +
      group('process', 'How a project runs', process) +
      group('faq', 'Questions', faq) +
      group('quotes', 'Testimonials', quotes, 'Add real feedback only, and only with the person\'s permission. While this list is empty the section stays hidden on the site.');
  }

  /* ---------- CONTACT ---------- */
  function renderContact() {
    var others = (data.contact.others || []).map(function (o, i) {
      return '<div class="st-pair st-pair--link"><div class="st-field"><label for="f-contact-others-' + i + '-label">Name</label><input type="text" id="f-contact-others-' + i + '-label" data-p="contact.others.' + i + '.label" value="' + esc(o.label) + '" placeholder="Behance" autocomplete="off"><p class="st-msg" role="alert"></p></div>' +
        '<div class="st-field"><label for="f-contact-others-' + i + '-url">Link</label><input type="text" id="f-contact-others-' + i + '-url" data-p="contact.others.' + i + '.url" data-v="url" value="' + esc(o.url) + '" placeholder="https://" autocomplete="off" spellcheck="false"><p class="st-msg" role="alert"></p></div>' +
        '<button type="button" class="st-btn st-btn--sm st-btn--danger" data-act="o-del" data-i="' + i + '">Remove</button></div>';
    }).join('');

    panel.innerHTML = '<div class="st-head"><div><h3 class="st-h" id="st-h" tabindex="-1">Contact and links</h3>' +
      '<p class="st-lead">Add your real details. Anything left empty shows as a placeholder and its button stays switched off, so nobody reaches a dead link.</p></div></div>' +
      '<div class="st-block">' +
      fieldHTML('Email address', 'contact.email', { v: 'email', mode: 'email', ph: 'you@example.com' }) +
      fieldHTML('WhatsApp number', 'contact.whatsapp', { v: 'phone', mode: 'tel', ph: '919876543210', hint: 'Country code first, digits only, no plus sign or spaces.' }) +
      fieldHTML('Fiverr link', 'contact.fiverr', { v: 'url', mode: 'url', ph: 'https://www.fiverr.com/yourname' }) +
      fieldHTML('Instagram link', 'contact.instagram', { v: 'url', mode: 'url', ph: 'https://www.instagram.com/yourname' }) +
      '</div><div class="st-block"><h4 class="st-h4">Other profiles</h4><p class="st-hint">Behance, LinkedIn, YouTube or anywhere else you want people to find you.</p>' + others +
      '<button type="button" class="st-btn" data-act="o-add">Add a profile</button></div>' +
      '<div class="st-block"><h4 class="st-h4">Site</h4>' +
      fieldHTML('Website address', 'site.url', { v: 'url', mode: 'url', ph: 'https://yourname.com', hint: 'Your final address. It makes the preview image work when someone shares your link. Leave empty until the site is live.' }) +
      fieldHTML('Contact form service address (optional)', 'contact.formEndpoint', { v: 'endpoint', mode: 'url', ph: 'https://formspree.io/f/…', hint: 'Only fill this in after you have set up a form service such as Formspree. Without it the form opens the visitor\'s email app instead of pretending to send.' }) +
      '</div><div class="st-block"><h4 class="st-h4">Contact section wording</h4>' +
      fieldHTML('Heading', 'contact.headline', { req: 1 }) + fieldHTML('Text', 'contact.text', { rows: 3, req: 1 }) + '</div>';
  }

  /* ---------- PUBLISH ---------- */
  function readiness() {
    var c = data.contact || {};
    var ps = data.projects || [];
    var real = ps.filter(function (p) { return !p.isDemo; }).length;
    var samples = ps.length - real;
    return [
      { ok: !!(c.email || c.whatsapp), need: true, label: 'A way for clients to reach you', tab: 'contact', go: 'f-contact-email' },
      { ok: !!c.email, label: c.email ? 'Email added' : 'Email address (recommended)', tab: 'contact', go: 'f-contact-email' },
      { ok: !!c.whatsapp, label: c.whatsapp ? 'WhatsApp added' : 'WhatsApp number (recommended)', tab: 'contact', go: 'f-contact-whatsapp' },
      { ok: real > 0, need: true, label: real ? plural(real, 'real project') + ' added' : 'Add at least one real project', tab: 'work' },
      { ok: samples === 0, need: true, label: samples ? plural(samples, 'sample project') + ' still on the site' : 'No sample projects left', tab: 'work' },
      { ok: !!(data.site && data.site.url), label: (data.site && data.site.url) ? 'Website address added' : 'Website address, for share previews (recommended)', tab: 'contact', go: 'f-site-url' },
      { ok: !!(c.fiverr || c.instagram || (c.others || []).some(function (o) { return o.url; })), label: 'A Fiverr, Instagram or other profile link (optional)', tab: 'contact', go: 'f-contact-fiverr' }
    ];
  }

  function check(ok) {
    return ok
      ? '<svg class="st-ck is-on" width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="11" r="10" fill="currentColor"/><path d="M6.5 11.5l3 3 6-6.5" fill="none" stroke="#111214" stroke-width="2" stroke-linecap="square"/></svg>'
      : '<svg class="st-ck" width="22" height="22" viewBox="0 0 22 22" aria-hidden="true"><circle cx="11" cy="11" r="9.2" fill="none" stroke="currentColor" stroke-width="1.6"/></svg>';
  }

  function renderPublish() {
    var items = readiness();
    var missing = items.filter(function (i) { return i.need && !i.ok; }).length;
    var ready = missing === 0;
    panel.innerHTML = '<div class="st-head"><div><h3 class="st-h" id="st-h" tabindex="-1">Publish</h3>' +
      '<p class="st-lead">Your edits are only visible here until you publish updated files.</p></div></div>' +
      '<div class="st-ready' + (ready ? ' is-ready' : '') + '"><p class="st-ready__t">' + (ready ? 'Ready to publish' : plural(missing, 'thing') + ' to finish before you publish') + '</p>' +
      '<ul class="st-checklist">' + items.map(function (i) {
        return '<li class="' + (i.ok ? 'is-done' : '') + '">' + check(i.ok) + '<span>' + esc(i.label) + '</span>' +
          (i.ok ? '' : '<button type="button" class="st-link" data-act="go" data-tab="' + i.tab + '"' + (i.go ? ' data-go="' + i.go + '"' : '') + '>Fix</button>') + '</li>';
      }).join('') + '</ul></div>' +
      '<div class="st-block"><h4 class="st-h4">1. Download your updated files</h4>' +
      '<p>One ZIP with your new <code>data/content.js</code> and every image you uploaded.</p>' +
      '<div class="st-actions"><button type="button" class="st-btn st-btn--primary" data-act="export">Download updated files</button></div>' +
      '<p class="st-result" id="st-result" role="status" aria-live="polite"></p></div>' +
      '<div class="st-block"><h4 class="st-h4">2. Put them on your website</h4><ol class="st-steps">' +
      '<li>Unzip the download. You will see a <code>data</code> folder and an <code>assets</code> folder.</li>' +
      '<li>Copy both into your website folder, next to <code>index.html</code>, and choose Replace or Merge when asked.</li>' +
      '<li>Upload the website folder to your hosting again. The README in the site folder lists some free hosts.</li></ol>' +
      '<p class="st-note">Your edits live only in this browser on this device. Download your files before you clear browser data or switch devices.</p></div>' +
      '<div class="st-block"><h4 class="st-h4">Start over</h4><p>Remove every edit stored in this browser and go back to the files on the site. This cannot be undone.</p>' +
      '<div class="st-actions"><button type="button" class="st-btn st-btn--danger" data-act="reset">Clear my edits on this device</button></div></div>';
  }

  function doExport(btn) {
    var out = $('#st-result');
    btn.disabled = true;
    out.textContent = 'Preparing your files…';
    out.classList.remove('is-bad');
    buildExport().then(function (r) {
      var a = document.createElement('a');
      var url = URL.createObjectURL(r.blob);
      a.href = url; a.download = 'ashwani-site-update-' + r.stamp + '.zip';
      document.body.appendChild(a); a.click(); a.remove();
      setTimeout(function () { URL.revokeObjectURL(url); }, 4000);
      var size = r.blob.size >= 1048576 ? (r.blob.size / 1048576).toFixed(1) + ' MB' : Math.max(1, Math.round(r.blob.size / 1024)) + ' KB';
      out.textContent = 'Downloaded: data/content.js and ' + plural(r.images, 'image') + ' (ZIP ' + size + ').';
    }).catch(function (err) {
      out.textContent = (err && err.message) || "Couldn't build the files.";
      out.classList.add('is-bad');
    }).then(function () { btn.disabled = false; });
  }

  /* ---------- events ---------- */
  function onClick(e) {
    var t = e.target.closest('[data-tab]');
    if (t && t.getAttribute('role') === 'tab') { switchTab(t.getAttribute('data-tab')); return; }

    var b = e.target.closest('[data-act]');
    if (!b || b.disabled) return;
    var act = b.getAttribute('data-act');
    var i = parseInt(b.getAttribute('data-i'), 10);

    switch (act) {
      case 'close': closeStudio(); break;
      case 'go':
        switchTab(b.getAttribute('data-tab'));
        var f = $('#' + b.getAttribute('data-go'));
        if (f) { f.focus(); f.scrollIntoView({ block: 'center' }); }
        break;
      case 'add': startDraft(-1); break;
      case 'edit': startDraft(i); break;
      case 'cancel':
        if (dirty && !arm(b, 'Discard changes?')) return;
        draft = null; dirty = false; draftRefs = {};
        cleanup(); renderTab();
        var h = $('#st-h'); if (h) h.focus();
        break;
      case 'up': case 'down':
        var j = act === 'up' ? i - 1 : i + 1;
        if (j < 0 || j >= data.projects.length) return;
        var tmp = data.projects[i]; data.projects[i] = data.projects[j]; data.projects[j] = tmp;
        commit(['projects']).then(function () {
          renderTab();
          var nb = $('[data-act="' + act + '"][data-i="' + j + '"]') || $('[data-act="edit"][data-i="' + j + '"]');
          if (nb) nb.focus();
        });
        break;
      case 'del':
        if (!arm(b, 'Press again to delete')) return;
        data.projects.splice(i, 1);
        commit(['projects']).then(function () { cleanup(); renderTab(); say('Project deleted'); });
        break;
      case 'rm-samples':
        if (!arm(b, 'Press again to remove')) return;
        data.projects = data.projects.filter(function (p) { return !p.isDemo; });
        commit(['projects']).then(function () { cleanup(); renderTab(); say('Sample projects removed'); });
        break;
      case 'g-del': draft.gallery.splice(i, 1); dirty = true; renderTab(); break;
      case 'd-add':
        draft.details.push({ label: '', value: '' }); dirty = true; renderTab();
        var di = $$('[data-dk="label"]'); if (di.length) di[di.length - 1].focus();
        break;
      case 'd-del': draft.details.splice(i, 1); dirty = true; renderTab(); break;
      case 'faq-add':
        data.faq.push({ q: 'New question', a: 'Answer' }); openGroups.faq = true;
        commit(['faq']).then(renderTab);
        break;
      case 'faq-del':
        if (!arm(b, 'Press again to delete')) return;
        data.faq.splice(i, 1); commit(['faq']).then(renderTab);
        break;
      case 'q-add': data.testimonials.push({ quote: '', name: '', role: '' }); openGroups.quotes = true; renderTab(); break;
      case 'q-del':
        if (!arm(b, 'Press again to delete')) return;
        data.testimonials.splice(i, 1); saveQuotes().then(renderTab);
        break;
      case 'o-add':
        data.contact.others.push({ label: '', url: '' }); renderTab();
        var ol = $$('[data-p$=".label"]'); if (ol.length) ol[ol.length - 1].focus();
        break;
      case 'o-del': data.contact.others.splice(i, 1); commit(['contact']).then(renderTab); break;
      case 'export': doExport(b); break;
      case 'reset':
        if (!arm(b, 'Press again to clear everything')) return;
        Site.resetLocal().then(function () {
          data = clone(Site.content); fillDefaults();
          draft = null; draftRefs = {}; dirty = false;
          renderTab(); say('Your edits on this device were cleared');
        });
        break;
    }
  }

  // A text field changed: validate it, then save it.
  function saveField(t) {
    var path = t.getAttribute('data-p');
    var as = t.getAttribute('data-as');
    var msg = t.closest('.st-field').querySelector('.st-msg');
    var r = validate(t.getAttribute('data-v'), t.value, t.hasAttribute('data-req'));
    if (!r.ok) {
      msg.textContent = r.msg;
      t.setAttribute('aria-invalid', 'true');
      return;
    }
    msg.textContent = '';
    t.removeAttribute('aria-invalid');
    var out = r.value;
    if (as === 'lines') out = String(t.value).split(/\n/).map(function (s) { return s.trim(); }).filter(Boolean);
    else if (as === 'paras') out = String(t.value).split(/\n\s*\n/).map(function (s) { return s.trim(); }).filter(Boolean);
    else if (t.value !== out) t.value = out;
    setP(data, path, out);
    var key = path.split('.')[0];
    if (key === 'testimonials') saveQuotes(); else commit([key]);
  }

  function onChange(e) {
    var t = e.target;
    if (t.hasAttribute('data-p')) { saveField(t); return; }
    if (t.hasAttribute('data-file')) {
      var kind = t.getAttribute('data-file');
      addFiles(kind, t.files);
      t.value = '';
      return;
    }
    if (draft && t.hasAttribute('data-d')) {
      var k = t.getAttribute('data-d');
      if (t.type === 'checkbox') draft[k] = k === 'size' ? (t.checked ? 'large' : '') : t.checked;
      else draft[k] = t.value;
      dirty = true;
    }
  }

  function onInput(e) {
    var t = e.target;
    if (!draft) return;
    if (t.hasAttribute('data-d') && t.type !== 'checkbox') { draft[t.getAttribute('data-d')] = t.value; dirty = true; }
    else if (t.hasAttribute('data-gi')) { draft.gallery[parseInt(t.getAttribute('data-gi'), 10)].alt = t.value; dirty = true; }
    else if (t.hasAttribute('data-di')) { draft.details[parseInt(t.getAttribute('data-di'), 10)][t.getAttribute('data-dk')] = t.value; dirty = true; }
  }

  function onDrop(e) {
    var zone = e.target.closest && e.target.closest('[data-drop]');
    if (!zone) return;
    if (e.type === 'dragover' || e.type === 'dragenter') { e.preventDefault(); zone.classList.add('is-over'); return; }
    if (e.type === 'dragleave') { zone.classList.remove('is-over'); return; }
    if (e.type === 'drop') {
      e.preventDefault(); zone.classList.remove('is-over');
      if (e.dataTransfer && e.dataTransfer.files && e.dataTransfer.files.length) addFiles('main', e.dataTransfer.files);
    }
  }

  function onTabKeys(e) {
    var keys = { ArrowRight: 1, ArrowLeft: -1, Home: 'first', End: 'last' };
    if (!(e.key in keys)) return;
    var idx = TABS.map(function (x) { return x[0]; }).indexOf(tab);
    var n = keys[e.key] === 'first' ? 0 : keys[e.key] === 'last' ? TABS.length - 1 : (idx + keys[e.key] + TABS.length) % TABS.length;
    e.preventDefault();
    switchTab(TABS[n][0], true);
  }

  /* ---------- open / close ---------- */
  function fillDefaults() {
    data.projects = data.projects || [];
    data.testimonials = data.testimonials || [];
    data.faq = data.faq || [];
    data.contact = data.contact || {};
    data.contact.others = data.contact.others || [];
    data.site = data.site || {};
  }

  function build() {
    dlg = document.createElement('dialog');
    dlg.className = 'studio';
    dlg.id = 'studio';
    dlg.setAttribute('aria-labelledby', 'st-title');
    dlg.innerHTML = '<div class="st-shell">' +
      '<header class="st-top"><div><h2 class="st-title" id="st-title">Studio</h2>' +
      '<p class="st-sub">Your private editor. Changes show on this device only until you publish.</p></div>' +
      '<button type="button" class="st-btn st-btn--primary" data-act="close">Done</button></header>' +
      '<div class="st-tabs" role="tablist" aria-label="Studio sections"></div>' +
      '<div class="st-body" id="st-panel" role="tabpanel" tabindex="-1"></div>' +
      '<footer class="st-foot"><p class="st-status" id="st-status" role="status" aria-live="polite"></p></footer></div>';
    document.body.appendChild(dlg);
    tabsEl = $('.st-tabs', dlg);
    panel = $('#st-panel', dlg);
    statusEl = $('#st-status', dlg);

    dlg.addEventListener('click', onClick);
    dlg.addEventListener('change', onChange);
    dlg.addEventListener('input', onInput);
    dlg.addEventListener('dragover', onDrop);
    dlg.addEventListener('dragenter', onDrop);
    dlg.addEventListener('dragleave', onDrop);
    dlg.addEventListener('drop', onDrop);
    tabsEl.addEventListener('keydown', onTabKeys);
    dlg.addEventListener('submit', function (e) {
      if (e.target.id === 'st-form') { e.preventDefault(); saveDraft(); }
    });
    // <details> toggle does not bubble, so listen while it travels down.
    dlg.addEventListener('toggle', function (e) {
      var g = e.target.getAttribute && e.target.getAttribute('data-g');
      if (g) openGroups[g] = e.target.open;
    }, true);
    dlg.addEventListener('cancel', function (e) {          // Esc key
      if (busy || (draft && dirty)) { e.preventDefault(); blockedByDraft(); }
    });
    dlg.addEventListener('close', function () {
      html.removeAttribute('data-studio-open');
      html.classList.remove('is-locked');
      if (viaHash && location.hash === '#studio') history.replaceState(null, '', location.pathname + location.search);
      if (Site.updatePill) Site.updatePill();
      if (Site.layout) Site.layout();
    });
    window.addEventListener('hashchange', function () {
      if (dlg.open && viaHash && location.hash !== '#studio' && !busy && !(draft && dirty)) { viaHash = false; dlg.close(); }
    });
  }

  function closeStudio() {
    if (!dlg || !dlg.open) return;
    if (blockedByDraft()) return;
    dlg.close();
  }

  function open() {
    if (!Site.isReady) { document.addEventListener('site:ready', open, { once: true }); return; }
    if (!dlg) build();
    if (dlg.open) return;
    data = clone(Site.content);
    fillDefaults();
    draft = null; dirty = false; draftRefs = {}; busy = 0;
    tab = 'work';
    viaHash = location.hash === '#studio';
    statusEl.textContent = DEFAULT_STATUS;
    statusEl.className = 'st-status';
    html.setAttribute('data-studio-open', '');
    html.classList.add('is-locked');
    renderTabs();
    renderTab();
    if (Site.updatePill) Site.updatePill();
    dlg.showModal();
    panel.scrollTop = 0;
    var heading = $('#st-h');           // start on the heading, not on the first button
    if (heading) heading.focus();
  }

  // app.js calls Studio.open() once this file has loaded.
  window.Studio = { open: open, close: closeStudio };
})();
