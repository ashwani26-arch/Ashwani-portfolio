/* =====================================================================
   ASHWANI — site script
   Builds the page from data/content.js, then wires up navigation,
   portfolio filters, the project viewer and the contact form.
   No frameworks, no build step.
   ===================================================================== */
(function () {
  'use strict';

  /* ---------- tiny helpers ---------- */
  var $ = function (s, r) { return (r || document).querySelector(s); };
  var $$ = function (s, r) { return Array.prototype.slice.call((r || document).querySelectorAll(s)); };
  var esc = function (s) {
    return String(s == null ? '' : s).replace(/[&<>"']/g, function (c) {
      return { '&': '&amp;', '<': '&lt;', '>': '&gt;', '"': '&quot;', "'": '&#39;' }[c];
    });
  };
  var clone = function (o) { return JSON.parse(JSON.stringify(o)); };
  var clamp = function (n, a, b) { return Math.min(b, Math.max(a, n)); };
  var getPath = function (obj, path) { return path.split('.').reduce(function (o, k) { return o == null ? o : o[k]; }, obj); };

  var html = document.documentElement;

  /* ---------- local storage for Studio edits (IndexedDB) ---------- */
  var Store = {
    db: null,
    open: function () {
      var self = this;
      return new Promise(function (resolve) {
        try {
          var req = indexedDB.open('ashwani-studio', 1);
          req.onupgradeneeded = function () {
            req.result.createObjectStore('kv');
            req.result.createObjectStore('img');
          };
          req.onsuccess = function () { self.db = req.result; resolve(true); };
          req.onerror = function () { resolve(false); };
          req.onblocked = function () { resolve(false); };
        } catch (e) { resolve(false); }
      });
    },
    run: function (store, mode, fn) {
      var self = this;
      return new Promise(function (resolve) {
        if (!self.db) { resolve(null); return; }
        try {
          var tx = self.db.transaction(store, mode);
          var req = fn(tx.objectStore(store));
          tx.oncomplete = function () { resolve(req && 'result' in req ? req.result : true); };
          tx.onerror = tx.onabort = function () { resolve(null); };
        } catch (e) { resolve(null); }
      });
    },
    get: function (s, k) { return this.run(s, 'readonly', function (o) { return o.get(k); }); },
    put: function (s, k, v) { return this.run(s, 'readwrite', function (o) { return o.put(v, k); }); },
    del: function (s, k) { return this.run(s, 'readwrite', function (o) { return o.delete(k); }); },
    clear: function (s) { return this.run(s, 'readwrite', function (o) { return o.clear(); }); }
  };

  /* ---------- content ---------- */
  var base = clone(window.SITE_CONTENT || {});
  var content = clone(base);
  var overrides = {};
  var hasLocal = false;
  var blobURLs = {};

  function mergeContent(b, ov) {
    var out = clone(b);
    if (!ov) return out;
    Object.keys(ov).forEach(function (k) {
      if (k === 'base' || k === 'version' || k === 'categories') return;
      var v = ov[k];
      if (Array.isArray(v)) out[k] = clone(v);
      else if (v && typeof v === 'object') out[k] = Object.assign({}, out[k], clone(v));
    });
    return out;
  }

  function projectRefs(p) {
    var refs = [p.image, p.thumb];
    (p.gallery || []).forEach(function (g) { refs.push(g.image, g.thumb); });
    return refs.filter(function (r) { return typeof r === 'string' && r.indexOf('idb:') === 0; });
  }

  function collectRefs(c) {
    var out = [];
    (c.projects || []).forEach(function (p) { out = out.concat(projectRefs(p)); });
    return out;
  }

  function src(ref) {
    if (!ref) return '';
    if (ref.indexOf('idb:') === 0) return blobURLs[ref] || '';
    return ref;
  }

  function loadBlobs() {
    var refs = collectRefs(content).filter(function (r) { return !blobURLs[r]; });
    return Promise.all(refs.map(function (r) {
      return Store.get('img', r.slice(4)).then(function (blob) {
        if (blob) blobURLs[r] = URL.createObjectURL(blob);
      });
    }));
  }

  function loadLocal() {
    return Store.open().then(function (ok) {
      if (!ok) return;
      return Store.get('kv', 'content').then(function (ov) {
        if (ov && typeof ov === 'object') {
          overrides = ov;
          content = mergeContent(base, ov);
          hasLocal = true;
        }
        return loadBlobs();
      });
    });
  }

  /* ---------- small lookups ---------- */
  function catLabel(id) {
    var c = (content.categories || []).filter(function (x) { return x.id === id; })[0];
    return c ? c.label : 'Other Creative Work';
  }
  function ratioOf(p) { return p.width && p.height ? clamp(p.width / p.height, 0.4, 3) : 4 / 3; }
  function safeUrl(u) {
    try {
      var url = new URL(String(u || '').trim());
      return (url.protocol === 'https:' || url.protocol === 'http:') ? url.href : '';
    } catch (e) { return ''; }
  }
  function shortUrl(u) { return u.replace(/^https?:\/\/(www\.)?/, '').replace(/\/$/, ''); }
  function digits(s) { return String(s || '').replace(/\D/g, ''); }
  function validEmail(s) { return /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(String(s || '').trim()); }
  function metaOf(p) { return p.format || catLabel(p.category); }

  /* ---------- text bindings (hero copy, role, year) ---------- */
  function renderBindings() {
    $$('[data-bind]').forEach(function (el) {
      var v = getPath(content, el.getAttribute('data-bind'));
      if (typeof v === 'string' && v) el.textContent = v;
    });
    var y = String(new Date().getFullYear());
    $$('[data-year]').forEach(function (el) { el.textContent = y; });
  }

  function renderMeta() {
    var site = safeUrl(content.site && content.site.url);
    if (!site) return;
    var root = site.replace(/\/$/, '') + '/';
    var img = new URL('assets/og/og-image.jpg', root).href;
    ['meta[property="og:image"]', 'meta[name="twitter:image"]'].forEach(function (sel) {
      var m = $(sel); if (m) m.setAttribute('content', img);
    });
    var link = $('link[rel="canonical"]');
    if (!link) { link = document.createElement('link'); link.rel = 'canonical'; document.head.appendChild(link); }
    link.href = root;
  }

  /* ---------- images: fade in once loaded ---------- */
  function watchImages(root) {
    $$('img[data-fade]', root).forEach(function (im) {
      if (im.classList.contains('is-loaded')) return;
      if (im.complete && im.naturalWidth) { im.classList.add('is-loaded'); return; }
      var done = function () { im.classList.add('is-loaded'); };
      im.addEventListener('load', done, { once: true });
      im.addEventListener('error', done, { once: true });
    });
  }

  /* ---------- boards (one framed design) ---------- */
  function boardHTML(p, o) {
    o = o || {};
    var s = src(o.full ? p.image : (p.thumb || p.image));
    return '<span class="board' + (p.pad ? ' board--pad' : '') + '" style="aspect-ratio:' + ratioOf(p).toFixed(4) + '">' +
      '<span class="board__img"><img data-fade src="' + esc(s) + '" alt="' + esc(p.alt || p.title) + '" width="' + (p.width || 1200) + '" height="' + (p.height || 800) + '" ' +
      (o.eager ? 'fetchpriority="high"' : 'loading="lazy"') + ' decoding="async"></span>' +
      '</span>';
  }

  function capHTML(p) {
    return '<span class="cap"><span class="cap__row"><span class="cap__title">' + esc(p.title) + '</span>' +
      (p.isDemo ? '<span class="tag-sample">Sample</span>' : '') + '</span>' +
      '<span class="cap__meta">' + esc(metaOf(p)) + '</span></span>';
  }

  /* ---------- hero previews ---------- */
  function pickStage() {
    var ps = content.projects || [];
    var used = {};
    function take(cats) {
      for (var i = 0; i < cats.length; i++) {
        var p = ps.filter(function (x) { return x.category === cats[i] && x.featured && !used[x.id]; })[0] ||
                ps.filter(function (x) { return x.category === cats[i] && !used[x.id]; })[0];
        if (p) { used[p.id] = 1; return p; }
      }
      var any = ps.filter(function (x) { return !used[x.id]; })[0];
      if (any) used[any.id] = 1;
      return any || null;
    }
    return { wide: take(['thumbnails']), square: take(['logos', 'social']), tall: take(['posters', 'social']) };
  }

  function stageItem(p, narrow, eager) {
    if (!p) return '';
    return '<a class="work-link stage__item' + (narrow ? ' stage__item--narrow' : '') + '" href="#work/' + esc(p.id) + '" data-open="' + esc(p.id) + '" data-all="1">' +
      boardHTML(p, { eager: eager }) + capHTML(p) + '</a>';
  }

  function renderStage() {
    var el = $('#stage');
    var c = pickStage();
    var n = [c.wide, c.square, c.tall].filter(Boolean).length;
    el.hidden = n === 0;
    if (!n) { el.innerHTML = ''; return; }
    el.innerHTML =
      '<div class="stage__col">' + stageItem(c.wide, false, true) + stageItem(c.square, !!c.wide && c.square && ratioOf(c.square) < 1.2, false) + '</div>' +
      '<div class="stage__col stage__col--b">' + stageItem(c.tall, false, true) + '</div>';
    watchImages(el);
  }

  /* ---------- portfolio: filters ---------- */
  var filter = 'all';
  var CAP = 62;

  function visibleProjects() {
    return (content.projects || []).filter(function (p) { return filter === 'all' || p.category === filter; });
  }

  function workHTML(p) {
    return '<div class="work" data-id="' + esc(p.id) + '" data-cat="' + esc(p.category) + '" data-ratio="' + ratioOf(p).toFixed(4) + '"' + (p.size === 'large' ? ' data-size="large"' : '') + '>' +
      '<a class="work-link" href="#work/' + esc(p.id) + '" data-open="' + esc(p.id) + '">' + boardHTML(p) + capHTML(p) + '</a></div>';
  }

  function renderPortfolio() {
    var ps = content.projects || [];
    var cats = (content.categories || []).filter(function (c) { return ps.some(function (p) { return p.category === c.id; }); });
    if (filter !== 'all' && !cats.some(function (c) { return c.id === filter; })) filter = 'all';
    var f = $('#filters');
    f.hidden = ps.length === 0 || cats.length < 2;
    f.innerHTML =
      '<button type="button" class="filter" data-filter="all" aria-pressed="false">All<span class="filter__n">' + ps.length + '</span></button>' +
      cats.map(function (c) {
        var n = ps.filter(function (p) { return p.category === c.id; }).length;
        return '<button type="button" class="filter" data-filter="' + esc(c.id) + '" aria-pressed="false">' + esc(c.label) + '<span class="filter__n">' + n + '</span></button>';
      }).join('');
    var g = $('#gallery');
    g.style.setProperty('--cap', CAP + 'px');
    g.classList.remove('is-ready');
    g.innerHTML = ps.length
      ? ps.map(workHTML).join('')
      : '<p class="empty">New work is on its way. Check back soon.</p>';
    watchImages(g);
    applyFilter(false);
    requestAnimationFrame(function () { g.classList.add('is-ready'); });
  }

  function applyFilter(animate) {
    var g = $('#gallery');
    var shown = 0;
    $$('.work', g).forEach(function (el) {
      var show = filter === 'all' || el.getAttribute('data-cat') === filter;
      clearTimeout(el._t);
      if (show) {
        shown++;
        if (el.hidden) { el.hidden = false; if (animate) { el.classList.add('is-enter'); setTimeout(function () { el.classList.remove('is-enter'); }, 600); } }
        el.classList.remove('is-out');
      } else if (animate) {
        el.classList.add('is-out');
        el._t = setTimeout(function () { if (el.classList.contains('is-out')) el.hidden = true; }, 360);
      } else {
        el.classList.add('is-out'); el.hidden = true;
      }
    });
    $$('.filter').forEach(function (b) { b.setAttribute('aria-pressed', String(b.getAttribute('data-filter') === filter)); });
    $('#filter-status').textContent = 'Showing ' + shown + (shown === 1 ? ' project' : ' projects') + (filter === 'all' ? '' : ' in ' + catLabel(filter));
    layoutGallery();
  }

  /* ---------- portfolio: masonry layout that never crops a design ---------- */
  function spanFor(el, cols) {
    if (cols < 2) return 1;
    if (cols === 2) return parseFloat(el.getAttribute('data-ratio')) >= 1.3 ? 2 : 1;
    return el.getAttribute('data-size') === 'large' ? 2 : 1;
  }

  function layoutGallery() {
    var g = $('#gallery');
    if (!g) return;
    var W = g.clientWidth;
    if (!W) return;
    var cols = W >= 840 ? 3 : 2;
    var gap = W >= 840 ? 28 : (W >= 560 ? 22 : 14);
    var rowGap = W >= 840 ? 28 : 20;
    var colW = (W - gap * (cols - 1)) / cols;
    var heights = [];
    for (var i = 0; i < cols; i++) heights.push(0);

    $$('.work', g).forEach(function (el) {
      if (el.hidden || el.classList.contains('is-out')) return;
      var span = Math.min(spanFor(el, cols), cols);
      var w = colW * span + gap * (span - 1);
      var h = w / parseFloat(el.getAttribute('data-ratio')) + CAP;
      var bestCol = 0, bestY = Infinity;
      for (var c = 0; c <= cols - span; c++) {
        var y = 0;
        for (var k = c; k < c + span; k++) y = Math.max(y, heights[k]);
        if (y < bestY - 0.5) { bestY = y; bestCol = c; }
      }
      el.style.width = w.toFixed(2) + 'px';
      el.style.transform = 'translate(' + (bestCol * (colW + gap)).toFixed(2) + 'px,' + bestY.toFixed(2) + 'px)';
      for (var j = bestCol; j < bestCol + span; j++) heights[j] = bestY + h + rowGap;
    });
    var tallest = Math.max.apply(null, heights);
    if (tallest > 0) g.style.height = Math.max(0, tallest - rowGap) + 'px';
  }

  /* ---------- project viewer ---------- */
  var viewer = $('#viewer');
  var vList = [], vIdx = 0, vOpener = null, vPushed = false, ctxAll = true, vClosing = false;

  function figHTML(im, eager) {
    return '<figure class="v-fig"><img src="' + esc(im.src) + '" alt="' + esc(im.alt) + '"' +
      (im.w && im.h ? ' width="' + im.w + '" height="' + im.h + '"' : '') + (eager ? '' : ' loading="lazy"') + ' decoding="async"></figure>';
  }

  function renderViewer() {
    var p = vList[vIdx];
    var imgs = [{ src: src(p.image), alt: p.alt || p.title, w: p.width, h: p.height }].concat((p.gallery || []).map(function (g) {
      return { src: src(g.image), alt: g.alt || p.title, w: g.width, h: g.height };
    }));
    $('#viewer-count').textContent = String(vIdx + 1).padStart(2, '0') + ' of ' + String(vList.length).padStart(2, '0');
    $('#viewer-cat').textContent = catLabel(p.category);
    $('#viewer-title').textContent = p.title;
    $('#viewer-desc').textContent = p.description || '';
    $('#viewer-desc').hidden = !p.description;
    $('#viewer-sample').hidden = !p.isDemo;
    var rows = [];
    if (p.format) rows.push(['Format', p.format]);
    (p.details || []).forEach(function (d) { if (d && d.label && d.value) rows.push([d.label, d.value]); });
    $('#viewer-details').innerHTML = rows.map(function (r) { return '<div><dt>' + esc(r[0]) + '</dt><dd>' + esc(r[1]) + '</dd></div>'; }).join('');
    $('#viewer-details').hidden = !rows.length;
    $('#viewer-media').innerHTML = figHTML(imgs[0], true);
    $('#viewer-more').innerHTML = imgs.slice(1).map(function (im) { return figHTML(im, false); }).join('');
    var multi = vList.length > 1;
    $('[data-prev]', viewer).hidden = !multi;
    $('[data-next]', viewer).hidden = !multi;
    $('#viewer-scroll').scrollTop = 0;
  }

  function openProject(id, fromHash) {
    var list = ctxAll ? (content.projects || []).slice() : visibleProjects();
    var idx = list.map(function (p) { return p.id; }).indexOf(id);
    if (idx < 0) { list = (content.projects || []).slice(); idx = list.map(function (p) { return p.id; }).indexOf(id); }
    if (idx < 0) return;
    vList = list; vIdx = idx;
    renderViewer();
    if (!viewer.open) {
      vPushed = !fromHash;
      if (typeof viewer.showModal === 'function') viewer.showModal(); else viewer.setAttribute('open', '');
    }
    html.classList.add('is-locked');
  }

  function stepViewer(d) {
    if (vList.length < 2) return;
    vIdx = (vIdx + d + vList.length) % vList.length;
    renderViewer();
    try { history.replaceState(null, '', '#work/' + encodeURIComponent(vList[vIdx].id)); } catch (e) {}
  }

  function onViewerClosed() {
    html.classList.remove('is-locked');
    if (vClosing) { vClosing = false; return; }
    if (/^#work\//.test(location.hash)) {
      if (vPushed) {
        vClosing = true;
        history.back();
        setTimeout(function () { vClosing = false; }, 300);
      } else {
        try { history.replaceState(null, '', location.pathname + location.search); } catch (e) {}
      }
    }
    vPushed = false;
    if (vOpener && document.contains(vOpener)) { try { vOpener.focus({ preventScroll: true }); } catch (e) {} }
  }

  viewer.addEventListener('close', onViewerClosed);
  viewer.addEventListener('click', function (e) {
    if (e.target === viewer) { viewer.close(); return; }
    var t = e.target.closest('[data-close],[data-close-go],[data-prev],[data-next]');
    if (!t) return;
    if (t.hasAttribute('data-close')) viewer.close();
    else if (t.hasAttribute('data-close-go')) { vOpener = null; viewer.close(); }
    else if (t.hasAttribute('data-prev')) stepViewer(-1);
    else if (t.hasAttribute('data-next')) stepViewer(1);
  });
  document.addEventListener('keydown', function (e) {
    if (!viewer.open) return;
    if (e.key === 'ArrowLeft') { e.preventDefault(); stepViewer(-1); }
    if (e.key === 'ArrowRight') { e.preventDefault(); stepViewer(1); }
  });

  function onHash() {
    var m = /^#work\/(.+)$/.exec(location.hash);
    if (m) {
      var id = decodeURIComponent(m[1]);
      if (!viewer.open || !vList[vIdx] || vList[vIdx].id !== id) openProject(id, !viewer.open && !vOpener);
    } else if (viewer.open) {
      vClosing = true;
      viewer.close();
    }
    if (location.hash === '#studio') loadStudio();
  }

  /* ---------- services ---------- */
  function renderServices() {
    $('#services-list').innerHTML = (content.services || []).map(function (s) {
      var ps = (content.projects || []).filter(function (p) { return p.category && p.category === s.category; });
      var prev = ps.filter(function (p) { return p.featured; })[0] || ps[0];
      var r = prev ? ratioOf(prev) : 1;
      return '<li class="service">' +
        '<h3 class="service__title">' + esc(s.title) + '</h3>' +
        '<div class="service__body"><p class="service__text">' + esc(s.text) + '</p>' +
        (s.price ? '<p class="service__price">' + esc(s.price) + '</p>' : '') +
        '<a class="service__cta" href="#contact" data-service="' + esc(s.id) + '">Enquire about this</a></div>' +
        (prev ? '<button type="button" class="service__prev" data-open="' + esc(prev.id) + '" data-all="1" aria-label="View project: ' + esc(prev.title) + '" style="width:min(100%,' + (120 * r).toFixed(1) + 'px)">' +
          boardHTML(prev) + '</button>' : '<span></span>') +
        '</li>';
    }).join('');
    watchImages($('#services-list'));
  }

  /* ---------- about, process, testimonials, FAQ ---------- */
  function renderAbout() {
    var a = content.about || {};
    var list = function (arr) { return (arr || []).map(function (t) { return '<li>' + esc(t) + '</li>'; }).join(''); };
    $('#about-body').innerHTML =
      '<figure class="about__photo"><img src="assets/about/ashwani-portrait.webp" alt="Portrait of Ashwani against a dark blue studio background" width="960" height="960" loading="lazy" decoding="async">' +
      '<figcaption>Ashwani, ' + esc(((content.site && content.site.role) || '').toLowerCase()) + '</figcaption></figure>' +
      '<div class="about__copy"><h2 class="about__title" id="about-title">' + esc(a.heading) + '</h2>' +
      '<div class="about__text">' + (a.paragraphs || []).map(function (t) { return '<p>' + esc(t) + '</p>'; }).join('') + '</div>' +
      '<div class="about__lists">' +
      '<div class="about__list"><h3>What I create</h3><ul>' + list(a.makes) + '</ul></div>' +
      '<div class="about__list"><h3>Who I work with</h3><ul>' + list(a['for']) + '</ul></div>' +
      '</div></div>';
  }

  function renderProcess() {
    $('#process-list').innerHTML = (content.process || []).map(function (s, i) {
      return '<li class="step"><span class="step__n" aria-hidden="true">' + String(i + 1).padStart(2, '0') + '</span>' +
        '<h3 class="step__title">' + esc(s.title) + '</h3><p class="step__text">' + esc(s.text) + '</p></li>';
    }).join('');
  }

  function renderTestimonials() {
    var list = (content.testimonials || []).filter(function (t) { return t && t.quote; });
    $('#testimonials').hidden = list.length === 0;
    $('#quotes').innerHTML = list.map(function (t) {
      return '<li><figure class="quote"><blockquote><p>' + esc(t.quote) + '</p></blockquote>' +
        '<figcaption>' + esc(t.name || '') + (t.role ? ', ' + esc(t.role) : '') + '</figcaption></figure></li>';
    }).join('');
  }

  function renderFaq() {
    var list = (content.faq || []).filter(function (x) { return x && x.q && x.a; });
    $('#faq').hidden = list.length === 0;
    $('#faq-list').innerHTML = list.map(function (x) {
      return '<details class="qa"><summary>' + esc(x.q) + '</summary><p>' + esc(x.a) + '</p></details>';
    }).join('');
  }

  /* ---------- contact ---------- */
  function channelRow(label, value, opts) {
    if (!value) {
      return '<li class="channel channel--empty"><span class="channel__label">' + esc(label) + '</span>' +
        '<span class="channel__value">Not added yet</span><span class="tag-ph">Placeholder</span></li>';
    }
    var acts = '';
    if (opts.href) acts += '<a class="channel__btn" href="' + esc(opts.href) + '"' + (opts.external ? ' target="_blank" rel="noopener noreferrer"' : '') + '>' + esc(opts.action) + '</a>';
    if (opts.copy) acts += '<button type="button" class="channel__btn" data-copy="' + esc(opts.copy) + '">Copy</button>';
    return '<li class="channel"><span class="channel__label">' + esc(label) + '</span>' +
      '<span class="channel__value">' + esc(value) + '</span><span class="channel__act">' + acts + '</span></li>';
  }

  function contactInfo() {
    var c = content.contact || {};
    var wa = digits(c.whatsapp);
    return {
      email: validEmail(c.email) ? c.email.trim() : '',
      wa: wa.length >= 8 ? wa : '',
      fiverr: safeUrl(c.fiverr),
      instagram: safeUrl(c.instagram),
      others: (c.others || []).map(function (o) { return { label: o.label, url: safeUrl(o.url) }; }).filter(function (o) { return o.label && o.url; }),
      endpoint: safeUrl(c.formEndpoint)
    };
  }

  function readForm() {
    var g = function (id) { var el = $('#' + id); return el ? el.value : ''; };
    return { name: g('f-name'), email: g('f-email'), type: g('f-type'), message: g('f-msg') };
  }

  function renderContact() {
    var c = content.contact || {};
    var info = contactInfo();
    var saved = $('#brief') ? readForm() : null;

    var rows =
      channelRow('Email', info.email, { href: 'mailto:' + info.email, action: 'Write', copy: info.email }) +
      channelRow('WhatsApp', info.wa ? '+' + info.wa : '', { href: 'https://wa.me/' + info.wa, action: 'Message', external: true, copy: '+' + info.wa }) +
      channelRow('Fiverr', info.fiverr ? shortUrl(info.fiverr) : '', { href: info.fiverr, action: 'Open', external: true }) +
      channelRow('Instagram', info.instagram ? shortUrl(info.instagram) : '', { href: info.instagram, action: 'Open', external: true }) +
      info.others.map(function (o) { return channelRow(o.label, shortUrl(o.url), { href: o.url, action: 'Open', external: true }); }).join('');

    var types = (content.services || []).map(function (s) { return s.title; }).concat(['Something else']);
    var actions = info.endpoint
      ? '<button class="btn btn--primary" type="submit">Send message</button>'
      : '<button class="btn btn--primary" type="button" data-act="email"' + (info.email ? '' : ' disabled title="Add your email to turn this on"') + '>Email this brief</button>' +
        '<button class="btn btn--ghost" type="button" data-act="wa"' + (info.wa ? '' : ' disabled title="Add your WhatsApp number to turn this on"') + '>WhatsApp this brief</button>' +
        '<button class="btn btn--ghost" type="button" data-act="copy">Copy brief</button>';
    var note = info.endpoint
      ? 'Your message is sent through the form service connected to this site.'
      : 'This form does not send anything by itself. It prepares your brief so you can send it from your own email or WhatsApp.';

    $('#contact-body').innerHTML =
      '<div class="contact__intro"><h2 class="contact__title" id="contact-title">' + esc(c.headline) + '</h2>' +
      '<p class="contact__text">' + esc(c.text) + '</p><ul class="channels">' + rows + '</ul></div>' +
      '<form class="brief" id="brief" novalidate' + (info.endpoint ? ' action="' + esc(info.endpoint) + '" method="post"' : '') + '>' +
      '<h3 class="brief__title">Send a project brief</h3>' +
      '<div class="field-row"><div class="field"><label for="f-name">Your name</label><input id="f-name" name="name" type="text" autocomplete="name" required></div>' +
      '<div class="field"><label for="f-email">Your email</label><input id="f-email" name="email" type="email" autocomplete="email"' + (info.endpoint ? ' required' : '') + '></div></div>' +
      '<div class="field"><label for="f-type">Project type</label><select id="f-type" name="type">' + types.map(function (t) { return '<option>' + esc(t) + '</option>'; }).join('') + '</select></div>' +
      '<div class="field"><label for="f-msg">Project details</label><textarea id="f-msg" name="message" required minlength="10" placeholder="What are you making, who is it for, and when do you need it?"></textarea></div>' +
      '<div class="brief__actions">' + actions + '</div>' +
      '<p class="brief__status" id="brief-status" role="status" aria-live="polite"></p>' +
      '<p class="brief__note">' + esc(note) + '</p></form>';

    if (saved) {
      $('#f-name').value = saved.name; $('#f-email').value = saved.email; $('#f-msg').value = saved.message;
      if (saved.type) $('#f-type').value = saved.type;
    }

    var soc = [];
    if (info.instagram) soc.push(['Instagram', info.instagram]);
    if (info.fiverr) soc.push(['Fiverr', info.fiverr]);
    info.others.forEach(function (o) { soc.push([o.label, o.url]); });
    var fs = $('#footer-social');
    fs.hidden = soc.length === 0;
    fs.innerHTML = soc.map(function (s) { return '<li><a href="' + esc(s[1]) + '" target="_blank" rel="noopener noreferrer">' + esc(s[0]) + '</a></li>'; }).join('');
  }

  function status(msg, isError) {
    var el = $('#brief-status');
    if (!el) return;
    el.textContent = msg;
    el.classList.toggle('is-error', !!isError);
  }

  function formValid() {
    var f = readForm();
    if (!f.name.trim()) { status('Please enter your name.', true); $('#f-name').focus(); return false; }
    if (contactInfo().endpoint && !validEmail(f.email)) { status('Please enter a valid email so I can reply.', true); $('#f-email').focus(); return false; }
    if (f.email.trim() && !validEmail(f.email)) { status('That email address does not look right.', true); $('#f-email').focus(); return false; }
    if (f.message.trim().length < 10) { status('Please add a few details about your project.', true); $('#f-msg').focus(); return false; }
    status('');
    return true;
  }

  function briefText() {
    var f = readForm();
    return 'Hello ASHWANI,\n\nI would like to discuss a project.\n\nProject type: ' + f.type + '\n\n' + f.message.trim() +
      '\n\nName: ' + f.name.trim() + (f.email.trim() ? '\nEmail: ' + f.email.trim() : '');
  }

  function copyText(text, done) {
    function fallback() {
      var ta = document.createElement('textarea');
      ta.value = text; ta.setAttribute('readonly', ''); ta.style.cssText = 'position:fixed;left:-9999px;top:0';
      document.body.appendChild(ta); ta.select();
      var ok = false;
      try { ok = document.execCommand('copy'); } catch (e) {}
      document.body.removeChild(ta);
      done(ok);
    }
    if (navigator.clipboard && navigator.clipboard.writeText) {
      navigator.clipboard.writeText(text).then(function () { done(true); }, fallback);
    } else fallback();
  }

  function openLink(url) {
    var a = document.createElement('a');
    a.href = url; a.target = '_blank'; a.rel = 'noopener noreferrer';
    document.body.appendChild(a); a.click(); document.body.removeChild(a);
  }

  function handleBriefAction(act) {
    var info = contactInfo();
    if (act === 'copy') {
      if (!formValid()) return;
      copyText(briefText(), function (ok) { status(ok ? 'Brief copied. Paste it into an email or message.' : 'Could not copy. Select the text in the project details box and copy it yourself.', !ok); });
    } else if (act === 'email' && info.email) {
      if (!formValid()) return;
      var f = readForm();
      openLink('mailto:' + info.email + '?subject=' + encodeURIComponent('Project enquiry: ' + f.type) + '&body=' + encodeURIComponent(briefText()));
      status('If your email app opens, the brief is ready there. Nothing is sent until you press send.');
    } else if (act === 'wa' && info.wa) {
      if (!formValid()) return;
      openLink('https://wa.me/' + info.wa + '?text=' + encodeURIComponent(briefText()));
      status('If WhatsApp opens, the message is ready there. Nothing is sent until you press send.');
    }
  }

  function submitBrief(form) {
    var info = contactInfo();
    if (!info.endpoint || !formValid()) return;
    status('Sending…');
    fetch(info.endpoint, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } })
      .then(function (r) {
        if (!r.ok) throw new Error('bad status');
        form.reset();
        status('Thanks, your message was sent.');
      })
      .catch(function () { status('The message could not be sent. Please use email or WhatsApp instead.', true); });
  }

  /* ---------- navigation ---------- */
  var header = $('.site-header');
  var menuBtn = $('#menu-btn');
  var menu = $('#menu');

  function setMenu(open) {
    menuBtn.setAttribute('aria-expanded', String(open));
    menu.hidden = !open;
    header.classList.toggle('menu-open', open);
    html.classList.toggle('is-locked', open || viewer.open);
    if (open) { var a = $('a', menu); if (a) a.focus(); }
  }

  function setCurrent(id) {
    $$('[data-nav]').forEach(function (a) {
      if (a.getAttribute('data-nav') === id) a.setAttribute('aria-current', 'true'); else a.removeAttribute('aria-current');
    });
  }

  function initNav() {
    menuBtn.addEventListener('click', function () { setMenu(menuBtn.getAttribute('aria-expanded') !== 'true'); });
    menu.addEventListener('click', function (e) { if (e.target.closest('a')) setMenu(false); });
    document.addEventListener('keydown', function (e) {
      if (e.key === 'Escape' && !menu.hidden) { setMenu(false); menuBtn.focus(); }
    });
    window.addEventListener('resize', function () { if (window.innerWidth >= 900 && !menu.hidden) setMenu(false); });
    window.addEventListener('scroll', function () { header.classList.toggle('is-stuck', window.scrollY > 8); }, { passive: true });
    setCurrent('home');
    if ('IntersectionObserver' in window) {
      var io = new IntersectionObserver(function (entries) {
        entries.forEach(function (en) { if (en.isIntersecting) setCurrent(en.target.getAttribute('data-section')); });
      }, { rootMargin: '-40% 0px -55% 0px' });
      $$('[data-section]').forEach(function (s) { io.observe(s); });
    }
  }

  /* ---------- Studio (loaded only when asked for) ---------- */
  var studioLoading = false;
  function loadStudio() {
    if (window.Studio) { window.Studio.open(); return; }
    if (studioLoading) return;
    studioLoading = true;
    var l = document.createElement('link');
    l.rel = 'stylesheet'; l.href = 'css/studio.css';
    document.head.appendChild(l);
    var s = document.createElement('script');
    s.src = 'js/studio.js';
    s.onload = function () { studioLoading = false; if (window.Studio) window.Studio.open(); };
    s.onerror = function () { studioLoading = false; };
    document.head.appendChild(s);
  }

  function updatePill() {
    var pill = $('#local-pill');
    if (hasLocal && !html.hasAttribute('data-studio-open')) {
      if (!pill) {
        pill = document.createElement('a');
        pill.id = 'local-pill'; pill.className = 'pill'; pill.href = '#studio';
        pill.textContent = 'Unpublished edits · Open Studio';
        document.body.appendChild(pill);
      }
    } else if (pill) pill.remove();
  }

  function renderAll() {
    renderBindings();
    renderMeta();
    renderStage();
    renderPortfolio();
    renderServices();
    renderAbout();
    renderProcess();
    renderTestimonials();
    renderFaq();
    renderContact();
    updatePill();
  }

  window.Site = {
    Store: Store,
    base: base,
    get content() { return content; },
    get hasLocal() { return hasLocal; },
    get overrides() { return overrides; },
    src: src,
    clone: clone,
    render: renderAll,
    layout: layoutGallery,
    catLabel: catLabel,
    updatePill: updatePill,
    saveOverrides: function (patch) {
      overrides = Object.assign({}, overrides, patch, { base: base.version });
      content = mergeContent(base, overrides);
      hasLocal = true;
      return Store.put('kv', 'content', overrides).then(function (r) { renderAll(); return r !== null; });
    },
    addImage: function (blob) {
      var id = 'img-' + Date.now().toString(36) + '-' + Math.random().toString(36).slice(2, 7);
      return Store.put('img', id, blob).then(function (r) {
        var ref = 'idb:' + id;
        blobURLs[ref] = URL.createObjectURL(blob);
        return { ref: ref, stored: r !== null };
      });
    },
    getBlob: function (ref) { return Store.get('img', String(ref).slice(4)); },
    resetLocal: function () {
      return Promise.all([Store.clear('kv'), Store.clear('img')]).then(function () {
        Object.keys(blobURLs).forEach(function (k) { URL.revokeObjectURL(blobURLs[k]); });
        blobURLs = {}; overrides = {}; content = clone(base); hasLocal = false; filter = 'all';
        renderAll();
      });
    }
  };

  /* ---------- events ---------- */
  document.addEventListener('click', function (e) {
    var open = e.target.closest('[data-open]');
    if (open) {
      ctxAll = open.hasAttribute('data-all');
      vOpener = open;
      if (open.tagName !== 'A') { e.preventDefault(); location.hash = '#work/' + encodeURIComponent(open.getAttribute('data-open')); }
      return;
    }

    var f = e.target.closest('[data-filter]');
    if (f) { filter = f.getAttribute('data-filter'); applyFilter(true); return; }

    var svc = e.target.closest('[data-service]');
    if (svc) {
      var s = (content.services || []).filter(function (x) { return x.id === svc.getAttribute('data-service'); })[0];
      var sel = $('#f-type');
      if (s && sel) sel.value = s.title;
      return;
    }

    var cp = e.target.closest('[data-copy]');
    if (cp) {
      copyText(cp.getAttribute('data-copy'), function (ok) {
        var old = cp.textContent;
        cp.textContent = ok ? 'Copied' : 'Select & copy';
        setTimeout(function () { cp.textContent = old; }, 1600);
      });
      return;
    }

    var act = e.target.closest('[data-act]');
    if (act && !act.disabled) handleBriefAction(act.getAttribute('data-act'));

    var st = e.target.closest('a[href="#studio"]');
    if (st) { e.preventDefault(); loadStudio(); }
  });

  document.addEventListener('submit', function (e) {
    if (e.target && e.target.id === 'brief') {
      e.preventDefault();
      submitBrief(e.target);
    }
  });

  window.addEventListener('hashchange', onHash);

  if ('ResizeObserver' in window) {
    var lastW = 0;
    new ResizeObserver(function () {
      var w = $('#gallery').clientWidth;
      if (w !== lastW) { lastW = w; layoutGallery(); }
    }).observe($('#gallery'));
  } else {
    window.addEventListener('resize', layoutGallery);
  }

  /* ---------- start ---------- */
  initNav();
  renderAll();
  onHash();
  loadLocal().then(function () {
    if (hasLocal) renderAll();
    window.Site.isReady = true;
    document.dispatchEvent(new CustomEvent('site:ready'));
    if (location.hash === '#studio') loadStudio();
  });
})();
