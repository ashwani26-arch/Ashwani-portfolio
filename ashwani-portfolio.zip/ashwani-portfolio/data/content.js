/* =====================================================================
   ASHWANI — SITE CONTENT
   This one file holds everything you may want to change: contact
   details, portfolio projects, service text, about text and more.

   Two ways to edit it:
   1. Easy way: open your site with  #studio  at the end of the address
      (for example  index.html#studio ). Upload images, add projects,
      type your contact details, then press "Download updated files".
   2. By hand: edit the text below. Keep the quotes and commas in place.

   Anything left as "" (empty) shows as a clearly marked placeholder.
   ===================================================================== */
window.SITE_CONTENT = {
  version: 2,

  site: {
    name: "ASHWANI",
    role: "Graphic Designer & Visual Creative",
    // Your final website address, e.g. "https://ashwani.design". Used for share previews.
    url: ""
  },

  hero: {
    headline: "Visuals That Make Your Brand Stand Out.",
    intro: "I create bold thumbnails, distinctive logos, promotional posters, and digital graphics for creators and businesses.",
    primaryCta: "Explore My Work",
    secondaryCta: "Let's Work Together"
  },

  // The filter buttons in the portfolio. "id" is used by projects below.
  categories: [
    { id: "thumbnails", label: "YouTube Thumbnails" },
    { id: "logos",      label: "Logo Design" },
    { id: "posters",    label: "Posters & Advertising" },
    { id: "social",     label: "Social Media Graphics" },
    { id: "other",      label: "Other Creative Work" }
  ],

  /* ---------------------------------------------------------------
     PORTFOLIO PROJECTS
     Every project below is a SAMPLE ("isDemo": true), made only to
     show how the portfolio will look. They are not client work.
     Replace them with your real work or delete them. In Studio you can
     remove all samples with one button.

     To add your own by hand: copy a block, change the fields and put
     your image in assets/work/ (or use Studio to upload it).
       image / thumb   main image, and an optional smaller copy for the grid
       width / height  image size in pixels (keeps proportions correct)
       format          short label shown under the title (optional)
       size            "large" makes the project wider on big screens (optional)
       featured        true shows it in the top-of-page preview (optional)
       gallery         extra images [{ "image": "...", "alt": "..." }] (optional)
       details         extra facts [{ "label": "Client", "value": "..." }] (optional)
       isDemo          true shows the "Sample" tag. Remove it for real work.
     --------------------------------------------------------------- */
  projects: [
    {
      id: "sample-thumbnail-01", title: "Tech review thumbnail", category: "thumbnails",
      description: "A sample layout for a product review video: heavy type, one clear focus and a bold arrow that points the eye. Made to show the style, not for a real client.",
      image: "assets/work/sample-thumbnail-01.webp", thumb: "assets/work/sample-thumbnail-01-sm.webp", width: 1280, height: 720,
      alt: "Sample YouTube thumbnail with the words Still Worth It in large white and yellow type beside a phone showing a 30 day countdown",
      format: "1280 × 720 px", isDemo: true, featured: true, size: "large"
    },
    {
      id: "sample-poster-01", title: "Open air music poster", category: "posters",
      description: "A sample event poster with a striped sunset, stacked condensed type and an information bar. Made to show the style, not for a real event.",
      image: "assets/work/sample-poster-01.webp", thumb: "assets/work/sample-poster-01-sm.webp", width: 1200, height: 1800,
      alt: "Sample music festival poster with a striped orange sun above the words Summer Sessions in black condensed type",
      format: "2:3 portrait", isDemo: true, featured: true
    },
    {
      id: "sample-logo-01", title: "Plant-based kitchen logo", category: "logos",
      description: "A sample logo for an imaginary restaurant, shown with space around it and in four colour versions. Made to show the process, not for a real client.",
      image: "assets/work/sample-logo-01.webp", thumb: "assets/work/sample-logo-01-sm.webp", width: 1000, height: 1000,
      alt: "Sample logo: a lime leaf inside a cream ring above the lowercase wordmark verda on dark green",
      format: "Logo and colour versions", isDemo: true, featured: true,
      gallery: [
        { image: "assets/work/sample-logo-01-variations.webp", thumb: "assets/work/sample-logo-01-variations-sm.webp", width: 1000, height: 1000,
          alt: "Sample logo shown in four versions: on cream, on lime, on dark green, and as a single colour mark" }
      ]
    },
    {
      id: "sample-photo-edit-01", title: "Landscape photo edit", category: "other",
      description: "A sample before and after layout for photo editing work: the same scene flat on the left and corrected on the right.",
      image: "assets/work/sample-photo-edit-01.webp", thumb: "assets/work/sample-photo-edit-01-sm.webp", width: 1500, height: 1000,
      alt: "Sample before and after comparison of a lake landscape: muted and grey on the left, vivid sunset colours on the right",
      format: "Before and after, 3:2", isDemo: true, size: "large"
    },
    {
      id: "sample-logo-02", title: "Perfume house wordmark", category: "logos",
      description: "A sample logo for an imaginary perfume house: a crescent mark with a spaced serif wordmark.",
      image: "assets/work/sample-logo-02.webp", thumb: "assets/work/sample-logo-02-sm.webp", width: 1000, height: 1000,
      alt: "Sample logo: a navy crescent moon above the spaced serif wordmark LUNE on a cream background",
      format: "Logo concept", isDemo: true
    },
    {
      id: "sample-social-01", title: "Thumbnail tips carousel", category: "social",
      description: "A sample three-slide carousel for Instagram or LinkedIn. One cover, then one idea per slide. Made to show consistency across a set.",
      image: "assets/work/sample-social-01.webp", thumb: "assets/work/sample-social-01-sm.webp", width: 1080, height: 1350,
      alt: "Sample social media cover slide with a huge lime number 5 and the words things every thumbnail needs",
      format: "1080 × 1350 px, 3 slides", isDemo: true,
      gallery: [
        { image: "assets/work/sample-social-01-slide-2.webp", thumb: "assets/work/sample-social-01-slide-2-sm.webp", width: 1080, height: 1350,
          alt: "Sample carousel slide 2 explaining that thumbnail text should be big enough to read on a phone" },
        { image: "assets/work/sample-social-01-slide-3.webp", thumb: "assets/work/sample-social-01-slide-3-sm.webp", width: 1080, height: 1350,
          alt: "Sample carousel slide 3 explaining that a thumbnail needs one clear focal point" }
      ]
    },
    {
      id: "sample-social-02", title: "Launch announcement post", category: "social",
      description: "A sample square post announcing a new collection, with oversized type, a sticker and a clear next step.",
      image: "assets/work/sample-social-02.webp", thumb: "assets/work/sample-social-02-sm.webp", width: 1080, height: 1080,
      alt: "Sample social media post in coral with the words New In in huge navy type and a yellow Out Now sticker",
      format: "1080 × 1080 px", isDemo: true
    },
    {
      id: "sample-poster-02", title: "Juice campaign poster", category: "posters",
      description: "A sample advertising poster for an imaginary juice brand: a clear product, one line of copy and a simple call to action.",
      image: "assets/work/sample-poster-02.webp", thumb: "assets/work/sample-poster-02-sm.webp", width: 1200, height: 1600,
      alt: "Sample advertising poster for orange juice with a bottle on an orange disc and the headline Squeezed this morning",
      format: "3:4 portrait", isDemo: true
    },
    {
      id: "sample-thumbnail-03", title: "Travel vlog thumbnail", category: "thumbnails",
      description: "A sample thumbnail for a travel vlog, built from layered shapes and one strong line of type.",
      image: "assets/work/sample-thumbnail-03.webp", thumb: "assets/work/sample-thumbnail-03-sm.webp", width: 1280, height: 720,
      alt: "Sample YouTube thumbnail with the words The Hidden Trail over layered purple mountains and a glowing sunrise",
      format: "1280 × 720 px", isDemo: true, size: "large"
    },
    {
      id: "sample-thumbnail-02", title: "Money mistake thumbnail", category: "thumbnails",
      description: "A sample high-contrast thumbnail for a finance or business channel: black on yellow, with a clear warning symbol.",
      image: "assets/work/sample-thumbnail-02.webp", thumb: "assets/work/sample-thumbnail-02-sm.webp", width: 1280, height: 720,
      alt: "Sample YouTube thumbnail with the words Stop Doing This in black type on yellow, beside a crossed out bar chart",
      format: "1280 × 720 px", isDemo: true
    }
  ],

  /* Services. "category" decides which portfolio work is shown beside it.
     "price" is optional: leave it empty until you have confirmed prices. */
  services: [
    {
      id: "thumbnails", title: "YouTube Thumbnail Design", category: "thumbnails",
      text: "Compelling, professionally composed thumbnails that communicate your video idea clearly and suit your content and audience.",
      price: ""
    },
    {
      id: "logos", title: "Logo Design", category: "logos",
      text: "Distinctive logo concepts shaped around a business's identity, audience and visual direction.",
      price: ""
    },
    {
      id: "posters", title: "Posters and Advertising", category: "posters",
      text: "Promotional posters and advertising creatives for campaigns, announcements, launches and other communication needs.",
      price: ""
    },
    {
      id: "social", title: "Social Media Graphics", category: "social",
      text: "Visually consistent graphics for social media content and digital marketing.",
      price: ""
    },
    {
      id: "photo", title: "Photo Editing", category: "other",
      text: "Image enhancement, creative editing and suitable image manipulation.",
      price: ""
    },
    {
      id: "custom", title: "Custom Graphic Design", category: "",
      text: "Other creative projects that fit my skills. Tell me what you have in mind.",
      price: ""
    }
  ],

  about: {
    heading: "I design visuals for creators and businesses.",
    paragraphs: [
      "I'm Ashwani, a graphic designer and visual creative. I work independently on thumbnails, logos, posters, social media graphics and other visual projects.",
      "Every project starts with who it is for and what it needs to do. From there I build the visuals around that goal."
    ],
    makes: [
      "YouTube thumbnails",
      "Logos and visual identities",
      "Promotional and advertising posters",
      "Social media posts and marketing creatives",
      "Photo editing and image enhancement",
      "Custom visual design"
    ],
    for: ["YouTube creators", "Businesses", "Brands", "Agencies", "Individuals"]
  },

  process: [
    { title: "Discuss", text: "Understand the project, audience, objectives and requirements." },
    { title: "Concept", text: "Establish the creative direction and develop suitable design ideas." },
    { title: "Design",  text: "Create and refine the selected direction." },
    { title: "Deliver", text: "Prepare and deliver the agreed final files." }
  ],

  faq: [
    { q: "What do you design?",
      a: "YouTube thumbnails, logos and brand visuals, promotional posters, social media graphics, photo edits, and other custom design work." },
    { q: "What should I send to get started?",
      a: "A short description of your idea and who it is for. Add any brand colours, logos, reference images or links you already have. If you are not sure what is useful, send what you have and we will work it out together." },
    { q: "How much does a project cost, and how long does it take?",
      a: "Both depend on what you need. Tell me about your project and I will talk you through it." },
    { q: "Which files will I receive?",
      a: "The final files are agreed with you during the project, based on where you will use the design." },
    { q: "Can you work on something that is not listed?",
      a: "Get in touch with what you have in mind. If it fits my skills, I will take it on. If it does not, I will tell you." }
  ],

  contact: {
    headline: "Have a Project in Mind?",
    text: "Tell me what you're creating. Let's discuss how thoughtful design can help bring your idea to life.",
    // Fill these in. Leave "" until you have the real details.
    email: "",        // e.g. "hello@yourdomain.com"
    whatsapp: "",     // digits with country code, e.g. "919876543210"
    fiverr: "",       // full link, e.g. "https://www.fiverr.com/yourname"
    instagram: "",    // full link, e.g. "https://www.instagram.com/yourname"
    others: [],       // e.g. [{ "label": "Behance", "url": "https://www.behance.net/yourname" }]
    // Optional: a form service address (for example from Formspree) so the form can send messages itself.
    formEndpoint: ""
  },

  // Add real client feedback only. While this list is empty, the section is hidden.
  // Example: [{ "quote": "...", "name": "Client name", "role": "Channel or company" }]
  testimonials: []
};
